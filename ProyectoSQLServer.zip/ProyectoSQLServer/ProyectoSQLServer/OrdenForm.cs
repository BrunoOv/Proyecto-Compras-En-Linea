﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{
    public partial class OrdenForm : Form
    {
        List<Proveedor> proveedorList = new List<Proveedor>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 
        int idP = 0;

        public OrdenForm()
        {
            InitializeComponent(); 
            textBoxTotal.Text = "0";
            conexion.Open(); //Abrimos conexion con la base de datos 
            llenalista();//Funcion que muestra en el datagridview las tuplas
            conexion.Close();
            conectaBD();
            comboBoxProveedor.SelectedIndex = -1;
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT O.Num_Orden, O.Fecha_Orden,cast(O.Total AS DECIMAL(10,2)), CONCAT(P.Nombre_Proveedor, ' | ' " +
                " ,P.Correo_Electronico) FROM Usuario.Proveedor P, Operaciones.Orden O WHERE P.Id_Proveedor=O.Id_Proveedor");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewOrden.DataSource = null;
            dataGridViewOrden.DataSource = dataTable;//Llenamos el dataGrid con los valores de las tuplas
            dataGridViewOrden.Columns[0].HeaderText = "Número de Orden";
            dataGridViewOrden.Columns[1].HeaderText = "Fecha de Orden";
            dataGridViewOrden.Columns[2].HeaderText = "Total";
            dataGridViewOrden.Columns[3].HeaderText = "Nombre Proveedor | Correo Electrónico";
            //dataGridViewOrden.Columns[4].HeaderText = "Correo Electrónico";
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            dateTimePickerFechaOrden.Value = DateTime.Now; //
            textBoxTotal.Text = "0";
            comboBoxProveedor.SelectedIndex = -1; //
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Usuario.Proveedor"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            //Llenamos la lista de proveedor
            while (sqlDataReader.Read())
            {
                Proveedor proveedor = new Proveedor();
                proveedor.Id_Proveedor = sqlDataReader.GetInt64(0);
                proveedor.Nombre_Proveedor = sqlDataReader.GetString(2) + " | " + sqlDataReader.GetString(1);
                //proveedor.Correo_Electronico = sqlDataReader.GetString(1) + " | " ;
                proveedor.Domicilio_Fiscal = sqlDataReader.GetString(3);

                proveedorList.Add(proveedor);
            }
            comboBoxProveedor.DataSource = proveedorList;
            comboBoxProveedor.DisplayMember = "Nombre_Proveedor";
            comboBoxProveedor.ValueMember = "Id_Proveedor";
        }

        private void dataGridViewOrden_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewOrden.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            if (decimal.Round(Convert.ToDecimal(dataGridViewOrden.CurrentRow.Cells[2].Value), 2).ToString() != "BDNull")
                textBoxTotal.Text = decimal.Round(Convert.ToDecimal(dataGridViewOrden.CurrentRow.Cells[2].Value), 2).ToString();
            else
                textBoxTotal.Text = "";//Llenamoos el textbox de total con los datos del datagridview
            dateTimePickerFechaOrden.Value = DateTime.Parse(dataGridViewOrden.CurrentRow.Cells[1].Value.ToString());
            for (int i = 0; i < proveedorList.Count; i++)
            {
                if (dataGridViewOrden.CurrentRow.Cells[3].Value.ToString() == proveedorList[i].Nombre_Proveedor)
                {
                    idP = comboBoxProveedor.FindStringExact(proveedorList[i].Nombre_Proveedor);
                    comboBoxProveedor.SelectedIndex = idP;
                    break;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string fecha = dateTimePickerFechaOrden.Value.ToString("yyyy-MM-dd");
                string consulta = "INSERT INTO Operaciones.Orden" + "(Id_Proveedor, Fecha_Orden, Total) " +
                    "VALUES(" + proveedorList[comboBoxProveedor.SelectedIndex].Id_Proveedor + ",'" + fecha + "'," + int.Parse(textBoxTotal.Text) + ")";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string fecha = dateTimePickerFechaOrden.Value.ToString("yyyy-MM-dd");
                string consulta = "UPDATE Operaciones.Orden SET Id_Proveedor=" + proveedorList[comboBoxProveedor.SelectedIndex].Id_Proveedor + ",Total="
                    + textBoxTotal.Text + ",Fecha_Orden='" + fecha + "' WHERE Num_Orden=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Operaciones.Orden WHERE Num_Orden=" + idA; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonDetalle_Click(object sender, EventArgs e)
        {
            DetalleOrdenForm detalleOrdenForm = new DetalleOrdenForm(); 
            detalleOrdenForm.ShowDialog();
        }
    }
}
