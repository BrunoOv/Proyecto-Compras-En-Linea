﻿namespace ProyectoSQLServer
{
    partial class DevolucionCarrito
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCarrito = new System.Windows.Forms.Label();
            this.labelProducto = new System.Windows.Forms.Label();
            this.labelCantidad = new System.Windows.Forms.Label();
            this.labelFecha = new System.Windows.Forms.Label();
            this.comboBoxCarrito = new System.Windows.Forms.ComboBox();
            this.comboBoxProducto = new System.Windows.Forms.ComboBox();
            this.textBoxCantidad = new System.Windows.Forms.TextBox();
            this.dateTimePickerFecha = new System.Windows.Forms.DateTimePicker();
            this.dataGridViewDevolucion = new System.Windows.Forms.DataGridView();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDevolucion)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCarrito
            // 
            this.labelCarrito.AutoSize = true;
            this.labelCarrito.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCarrito.Location = new System.Drawing.Point(12, 9);
            this.labelCarrito.Name = "labelCarrito";
            this.labelCarrito.Size = new System.Drawing.Size(75, 30);
            this.labelCarrito.TabIndex = 0;
            this.labelCarrito.Text = "Carrito";
            // 
            // labelProducto
            // 
            this.labelProducto.AutoSize = true;
            this.labelProducto.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelProducto.Location = new System.Drawing.Point(12, 54);
            this.labelProducto.Name = "labelProducto";
            this.labelProducto.Size = new System.Drawing.Size(97, 30);
            this.labelProducto.TabIndex = 1;
            this.labelProducto.Text = "Producto";
            // 
            // labelCantidad
            // 
            this.labelCantidad.AutoSize = true;
            this.labelCantidad.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCantidad.Location = new System.Drawing.Point(12, 97);
            this.labelCantidad.Name = "labelCantidad";
            this.labelCantidad.Size = new System.Drawing.Size(96, 30);
            this.labelCantidad.TabIndex = 2;
            this.labelCantidad.Text = "Cantidad";
            // 
            // labelFecha
            // 
            this.labelFecha.AutoSize = true;
            this.labelFecha.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelFecha.Location = new System.Drawing.Point(12, 143);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(67, 30);
            this.labelFecha.TabIndex = 3;
            this.labelFecha.Text = "Fecha";
            // 
            // comboBoxCarrito
            // 
            this.comboBoxCarrito.FormattingEnabled = true;
            this.comboBoxCarrito.Location = new System.Drawing.Point(132, 16);
            this.comboBoxCarrito.Name = "comboBoxCarrito";
            this.comboBoxCarrito.Size = new System.Drawing.Size(200, 23);
            this.comboBoxCarrito.TabIndex = 4;
            this.comboBoxCarrito.SelectedIndexChanged += new System.EventHandler(this.comboBoxCarrito_SelectedIndexChanged);
            // 
            // comboBoxProducto
            // 
            this.comboBoxProducto.FormattingEnabled = true;
            this.comboBoxProducto.Location = new System.Drawing.Point(132, 61);
            this.comboBoxProducto.Name = "comboBoxProducto";
            this.comboBoxProducto.Size = new System.Drawing.Size(200, 23);
            this.comboBoxProducto.TabIndex = 5;
            // 
            // textBoxCantidad
            // 
            this.textBoxCantidad.Location = new System.Drawing.Point(132, 104);
            this.textBoxCantidad.Name = "textBoxCantidad";
            this.textBoxCantidad.Size = new System.Drawing.Size(100, 23);
            this.textBoxCantidad.TabIndex = 6;
            // 
            // dateTimePickerFecha
            // 
            this.dateTimePickerFecha.Enabled = false;
            this.dateTimePickerFecha.Location = new System.Drawing.Point(132, 150);
            this.dateTimePickerFecha.Name = "dateTimePickerFecha";
            this.dateTimePickerFecha.Size = new System.Drawing.Size(200, 23);
            this.dateTimePickerFecha.TabIndex = 7;
            // 
            // dataGridViewDevolucion
            // 
            this.dataGridViewDevolucion.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDevolucion.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDevolucion.Location = new System.Drawing.Point(12, 192);
            this.dataGridViewDevolucion.Name = "dataGridViewDevolucion";
            this.dataGridViewDevolucion.RowTemplate.Height = 25;
            this.dataGridViewDevolucion.Size = new System.Drawing.Size(776, 246);
            this.dataGridViewDevolucion.TabIndex = 8;
            this.dataGridViewDevolucion.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDevolucion_CellClick);
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAgregar.Location = new System.Drawing.Point(354, 16);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(113, 41);
            this.buttonAgregar.TabIndex = 9;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonModificar.Location = new System.Drawing.Point(504, 16);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(109, 41);
            this.buttonModificar.TabIndex = 10;
            this.buttonModificar.Text = "Modificar";
            this.buttonModificar.UseVisualStyleBackColor = true;
            this.buttonModificar.Click += new System.EventHandler(this.buttonModificar_Click);
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonEliminar.Location = new System.Drawing.Point(642, 16);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(112, 41);
            this.buttonEliminar.TabIndex = 11;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // DevolucionCarrito
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.dataGridViewDevolucion);
            this.Controls.Add(this.dateTimePickerFecha);
            this.Controls.Add(this.textBoxCantidad);
            this.Controls.Add(this.comboBoxProducto);
            this.Controls.Add(this.comboBoxCarrito);
            this.Controls.Add(this.labelFecha);
            this.Controls.Add(this.labelCantidad);
            this.Controls.Add(this.labelProducto);
            this.Controls.Add(this.labelCarrito);
            this.Name = "DevolucionCarrito";
            this.Text = "Devolucion de Carrito";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDevolucion)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelCarrito;
        private Label labelProducto;
        private Label labelCantidad;
        private Label labelFecha;
        private ComboBox comboBoxCarrito;
        private ComboBox comboBoxProducto;
        private TextBox textBoxCantidad;
        private DateTimePicker dateTimePickerFecha;
        private DataGridView dataGridViewDevolucion;
        private Button buttonAgregar;
        private Button buttonModificar;
        private Button buttonEliminar;
    }
}