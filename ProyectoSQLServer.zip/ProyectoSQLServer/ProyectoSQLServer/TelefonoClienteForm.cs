﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{

    public partial class TelefonoClienteForm : Form
    {
        List<Cliente> clienteList = new List<Cliente>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 

        public TelefonoClienteForm()
        {
            InitializeComponent();
            conectaBD();
            comboBoxCliente.SelectedIndex = -1;
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista();
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query = string.Concat("SELECT * FROM Datos.Telefono_Cliente"); //Sentencia para mostrar todas la tuplas
            string query1 = string.Concat("SELECT T.Id_Cliente, T.Numero,CONCAT(C.Nombre_Cliente, ' | ' ,C.Correo_Electronico) FROM Usuario.Cliente C, " +
                "Datos.Telefono_Cliente T WHERE C.Id_Cliente=T.Id_Cliente");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewTelefonoC.DataSource = null;
            //dataTable.Rows.RemoveAt(-1);
            dataGridViewTelefonoC.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewTelefonoC.Columns[0].HeaderText = "Id Cliente";
            dataGridViewTelefonoC.Columns[1].HeaderText = "Número";
            dataGridViewTelefonoC.Columns[2].HeaderText = "Nombre Cliente | Correo Electrónico";
            //dataGridViewTelefonoC.Columns[3].HeaderText = "Correo Electrónico";
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxNumero.Clear(); //Limpiamos textbox de Nombre
            comboBoxCliente.SelectedIndex = -1; //Limpiamos textbox de Correo
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Usuario.Cliente"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Cliente cliente = new Cliente();
                cliente.Id_Cliente = sqlDataReader.GetInt64(0);
                cliente.Nombre_Cliente= sqlDataReader.GetString(1) + " | " + sqlDataReader.GetString(2);
                //cliente.Correo_Electronico = sqlDataReader.GetString(2);

                clienteList.Add(cliente);
            }
            comboBoxCliente.DataSource = clienteList;
            comboBoxCliente.DisplayMember = "Nombre_Cliente";
            comboBoxCliente.ValueMember = "Id_Cliente";
        }

        private void dataGridViewTelefonoC_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewTelefonoC.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            textBoxNumero.Text = dataGridViewTelefonoC.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            //comboBoxCliente.SelectedIndex = dataGridViewTelefonoC.CurrentRow.Cells[3].Value.ToString();//Llenamos el textbox de correo con los datos del datagridview
            for (int i = 0; i < clienteList.Count;i++)
            {
                if (clienteList[i].Id_Cliente == idA)
                {
                    int id = comboBoxCliente.FindStringExact(clienteList[i].Nombre_Cliente);
                    comboBoxCliente.SelectedIndex = id;
                }
            }

        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        

        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string consulta = "INSERT INTO Datos.Telefono_Cliente" + "(Id_Cliente, Numero) " +
                    "VALUES(" + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + ",'" + textBoxNumero.Text + "')";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero duplicado"); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "UPDATE Datos.Telefono_Cliente SET Id_Cliente=" + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + ",Numero='"
                    + textBoxNumero.Text + "' WHERE Id_Cliente=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero duplicado"); //Error en la conexion
            }
        }

        private void buttonElimina_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Datos.Telefono_Cliente WHERE Id_Cliente=" + idA + "AND Numero=" + textBoxNumero.Text; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
