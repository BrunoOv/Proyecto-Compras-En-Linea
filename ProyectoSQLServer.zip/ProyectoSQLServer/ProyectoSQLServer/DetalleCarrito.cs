﻿using System.Data;
using System.Data.SqlClient;

namespace ProyectoSQLServer
{
    public partial class DetalleCarrito : Form
    {
        List<Producto> productoList = new List<Producto>();
        List<Carrito> carritoList = new List<Carrito>();
        List<Cliente> clienteList = new List<Cliente>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 
        long idP  = 0;//Variable para id de Producto para cuando se modificara o eliminara

        public DetalleCarrito()
        {
            InitializeComponent();
            conectaBD();//Funcion para hacer la conexion con la base de datos
            //Inicializamos herramientas para el buen uso de nuestro programa
            comboBoxCarrito.SelectedIndex = -1;
            comboBoxProducto.SelectedIndex = -1;
            textBoxSubtotal.Text = "0";
            textBoxCantidad.Clear();
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista();
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT CONCAT(C.Id_Carrito, ' | ', U.Nombre_Cliente), D.Cantidad,cast(D.SubTotal AS DECIMAL(10,2)), CONCAT( P.Nombre_Producto, " +
                "' | ',cast(P.Precio_Publico_Producto AS DECIMAL(10,2)) )" +
                "FROM Operaciones.Detalle_Carrito D, Articulo.Producto P,Operaciones.Carrito_Venta C, Usuario.Cliente U, Datos.Tarjeta_Cliente T " +
                "WHERE C.Id_Carrito = D.Id_Carrito AND D.Id_Producto = P.Id_Producto AND U.Id_Cliente = T.Id_Cliente AND T.Id_Tarjeta = C.Id_Tarjeta_Cliente ");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewDetalleCarrito.DataSource = null;
            dataGridViewDetalleCarrito.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewDetalleCarrito.Columns[0].HeaderText = "Carrito | Cliente";
            dataGridViewDetalleCarrito.Columns[1].HeaderText = "Cantidad";
            dataGridViewDetalleCarrito.Columns[2].HeaderText = "SubTotal";
            dataGridViewDetalleCarrito.Columns[3].HeaderText = "Nombre Producto | Precio Publico Producto";
            //dataGridViewDetalleCarrito.Columns[4].HeaderText = "Precio Publico Producto";
            CarritoForm carritoForm = Application.OpenForms.OfType<CarritoForm>().FirstOrDefault();
            if (carritoForm != null)
                carritoForm.muestra();
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            //Limpiamos herramientas de form
            comboBoxCarrito.SelectedIndex = -1;
            comboBoxProducto.SelectedIndex = -1;
            textBoxSubtotal.Text = "0";
            textBoxCantidad.Clear();
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Articulo.Producto"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            while (sqlDataReader.Read())
            {
                //Llenamos la lista de Producto que tenemos en la base
                Producto producto = new Producto();
                producto.Id_Producto = sqlDataReader.GetInt64(0);
                producto.Nombre_Producto = sqlDataReader.GetString(1) + " | " + Math.Round(sqlDataReader.GetDecimal(2),2);
                //producto.Precio_Publico_Producto = sqlDataReader.GetDecimal(2);
                producto.Precio_Proveedor_Producto = sqlDataReader.GetDecimal(3);
                producto.Color = sqlDataReader.GetString(4);
                //producto.Stock = sqlDataReader.GetInt32(5);

                productoList.Add(producto);
            }
            comboBoxProducto.DataSource = productoList; //Le damos valor al combobox Producto
            comboBoxProducto.DisplayMember = "Nombre_Producto";
            comboBoxProducto.ValueMember = "Id_Producto";


            query = string.Concat("SELECT C.Id_Carrito, C.Id_Tarjeta_Cliente, C.Forma_De_Pago, C.Fecha_Venta, C.Total_Carrito, U.Nombre_Cliente" +
                " FROM Operaciones.Carrito_Venta C, Datos.Tarjeta_Cliente T, Usuario.Cliente U " +
                "WHERE T.Id_Cliente = U.Id_Cliente AND T.Id_Tarjeta = C.Id_Tarjeta_Cliente"); //Sentencia para mostrar todas la tuplas
            

            sqlDataReader.Close();
            command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            sqlDataReader = command.ExecuteReader();
            while (sqlDataReader.Read())
            {
                //Llenamos la lista de Carrito que tenemos en la base
                Carrito carrito = new Carrito();
                carrito.Id_Carrito = sqlDataReader.GetInt64(0);
                carrito.Id_Tarjeta = sqlDataReader.GetInt64(1);
                carrito.FormaPago = sqlDataReader.GetString(2);
                carrito.FechaVenta = sqlDataReader.GetDateTime(3);
                carrito.Total = sqlDataReader.GetDecimal(4);
                carrito.Cliente =   sqlDataReader.GetString(5);
                carrito.idynombre = carrito.Id_Carrito + " - " + carrito.Cliente;

                carritoList.Add(carrito);
            }
            comboBoxCarrito.DataSource = carritoList; //Le damos valor al combobox Carrito
            comboBoxCarrito.DisplayMember = "idynombre";
            comboBoxCarrito.ValueMember = "idynombre";
        }

        private void dataGridViewDetalleCarrito_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string g = dataGridViewDetalleCarrito.CurrentRow.Cells[0].Value.ToString();
            string idCa = ""; //El siguiente cilo es para extraer solo el id del Carrito
            for (int i = 0; i < g.Length; i++)
            {
                if (g[i] != ' ')
                {
                    idCa += g[i];
                }
                else
                    break;
            }

            idA = int.Parse(idCa); //Convertirmos el id a int
            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Nombre_Producto == dataGridViewDetalleCarrito.CurrentRow.Cells[3].Value.ToString())
                {
                    idP = productoList[i].Id_Producto; //Damos valor al idP
                    break;
                }
            }
            textBoxCantidad.Text = dataGridViewDetalleCarrito.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de cantidad con los datos del datagridview
            textBoxSubtotal.Text = dataGridViewDetalleCarrito.CurrentRow.Cells[2].Value.ToString();//Llenamoos el textbox de cantidad con los datos del datagridview
            for (int i = 0; i < carritoList.Count; i++)
            {
                if (carritoList[i].Id_Carrito == idA)
                {
                    int id = comboBoxCarrito.FindString(carritoList[i].Id_Carrito.ToString());
                    comboBoxCarrito.SelectedIndex = id; //Seleccionamos el el combobox el elegido
                    break;
                }
            }
            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Id_Producto == idP)
                {
                    int id = comboBoxProducto.FindStringExact(productoList[i].Nombre_Producto);
                    comboBoxProducto.SelectedIndex = id; //Seleccionamos en el combobox el elegido
                    break;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void insertaRegistro()
        {
            try
            {
                if (textBoxCantidad.Text == "0")
                {
                    MessageBox.Show("Cantidad invalida");
                }
                else
                {
                    conexion.Open();//Abre la conexion
                    string consulta = "INSERT INTO Operaciones.Detalle_Carrito (Id_Carrito, Id_Producto,Cantidad,SubTotal) " +
                        "VALUES(" + carritoList[comboBoxCarrito.SelectedIndex].Id_Carrito + "," + productoList[comboBoxProducto.SelectedIndex].Id_Producto + ",'" + textBoxCantidad.Text +
                        "','" + textBoxSubtotal.Text + "')";
                    //Sentencia para insertar detalles carrito con los datos de las textbox
                    SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                    command.ExecuteNonQuery(); //Ejecutamos el comando
                    conexion.Close(); //Cerramos conexion
                    limpia(); //Limpiamos textbox
                }
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "UPDATE Operaciones.Detalle_Carrito SET Id_Carrito=" + carritoList[comboBoxCarrito.SelectedIndex].Id_Carrito + ",Id_Producto="
                    + productoList[comboBoxProducto.SelectedIndex].Id_Producto + ",Cantidad=" + textBoxCantidad.Text + ", SubTotal="+ textBoxSubtotal.Text +
                    " WHERE Id_Carrito=" + idA + " AND Id_Producto=" + idP;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero Duplicado de Tarjeta"); //Error en la conexion

            }


        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Operaciones.Detalle_Carrito WHERE Id_Carrito=" + idA + "AND Id_Producto=" + idP + "AND Cantidad=" + textBoxCantidad.Text + 
                    "AND Subtotal=" + textBoxSubtotal.Text ; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
