﻿namespace ProyectoSQLServer
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonCliente = new System.Windows.Forms.Button();
            this.buttonProveedor = new System.Windows.Forms.Button();
            this.buttonProducto = new System.Windows.Forms.Button();
            this.buttonOrden = new System.Windows.Forms.Button();
            this.buttonCarrito = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonCliente
            // 
            this.buttonCliente.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCliente.Location = new System.Drawing.Point(10, 9);
            this.buttonCliente.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonCliente.Name = "buttonCliente";
            this.buttonCliente.Size = new System.Drawing.Size(119, 40);
            this.buttonCliente.TabIndex = 0;
            this.buttonCliente.Text = "Cliente";
            this.buttonCliente.UseVisualStyleBackColor = true;
            this.buttonCliente.Click += new System.EventHandler(this.buttonCliente_Click);
            // 
            // buttonProveedor
            // 
            this.buttonProveedor.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonProveedor.Location = new System.Drawing.Point(135, 9);
            this.buttonProveedor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonProveedor.Name = "buttonProveedor";
            this.buttonProveedor.Size = new System.Drawing.Size(135, 40);
            this.buttonProveedor.TabIndex = 1;
            this.buttonProveedor.Text = "Proveedor";
            this.buttonProveedor.UseVisualStyleBackColor = true;
            this.buttonProveedor.Click += new System.EventHandler(this.buttonProveedor_Click);
            // 
            // buttonProducto
            // 
            this.buttonProducto.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonProducto.Location = new System.Drawing.Point(10, 53);
            this.buttonProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonProducto.Name = "buttonProducto";
            this.buttonProducto.Size = new System.Drawing.Size(135, 40);
            this.buttonProducto.TabIndex = 2;
            this.buttonProducto.Text = "Producto";
            this.buttonProducto.UseVisualStyleBackColor = true;
            this.buttonProducto.Click += new System.EventHandler(this.buttonProducto_Click);
            // 
            // buttonOrden
            // 
            this.buttonOrden.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonOrden.Location = new System.Drawing.Point(151, 54);
            this.buttonOrden.Name = "buttonOrden";
            this.buttonOrden.Size = new System.Drawing.Size(119, 39);
            this.buttonOrden.TabIndex = 3;
            this.buttonOrden.Text = "Orden";
            this.buttonOrden.UseVisualStyleBackColor = true;
            this.buttonOrden.Click += new System.EventHandler(this.buttonOrden_Click);
            // 
            // buttonCarrito
            // 
            this.buttonCarrito.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonCarrito.Location = new System.Drawing.Point(10, 98);
            this.buttonCarrito.Name = "buttonCarrito";
            this.buttonCarrito.Size = new System.Drawing.Size(135, 38);
            this.buttonCarrito.TabIndex = 4;
            this.buttonCarrito.Text = "Carrito";
            this.buttonCarrito.UseVisualStyleBackColor = true;
            this.buttonCarrito.Click += new System.EventHandler(this.buttonCarrito_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(277, 149);
            this.Controls.Add(this.buttonCarrito);
            this.Controls.Add(this.buttonOrden);
            this.Controls.Add(this.buttonProducto);
            this.Controls.Add(this.buttonProveedor);
            this.Controls.Add(this.buttonCliente);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Form1";
            this.Text = "Compras en Linea";
            this.ResumeLayout(false);

        }

        #endregion

        private Button buttonCliente;
        private Button buttonProveedor;
        private Button buttonProducto;
        private Button buttonOrden;
        private Button buttonCarrito;
    }
}