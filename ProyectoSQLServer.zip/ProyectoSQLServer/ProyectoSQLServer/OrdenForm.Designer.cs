﻿namespace ProyectoSQLServer
{
    partial class OrdenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelFecha = new System.Windows.Forms.Label();
            this.labelTotal = new System.Windows.Forms.Label();
            this.labelProveedor = new System.Windows.Forms.Label();
            this.dateTimePickerFechaOrden = new System.Windows.Forms.DateTimePicker();
            this.textBoxTotal = new System.Windows.Forms.TextBox();
            this.comboBoxProveedor = new System.Windows.Forms.ComboBox();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            this.dataGridViewOrden = new System.Windows.Forms.DataGridView();
            this.buttonDetalle = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrden)).BeginInit();
            this.SuspendLayout();
            // 
            // labelFecha
            // 
            this.labelFecha.AutoSize = true;
            this.labelFecha.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelFecha.Location = new System.Drawing.Point(12, 9);
            this.labelFecha.Name = "labelFecha";
            this.labelFecha.Size = new System.Drawing.Size(160, 30);
            this.labelFecha.TabIndex = 0;
            this.labelFecha.Text = "Fecha de Orden";
            // 
            // labelTotal
            // 
            this.labelTotal.AutoSize = true;
            this.labelTotal.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelTotal.Location = new System.Drawing.Point(12, 49);
            this.labelTotal.Name = "labelTotal";
            this.labelTotal.Size = new System.Drawing.Size(57, 30);
            this.labelTotal.TabIndex = 1;
            this.labelTotal.Text = "Total";
            // 
            // labelProveedor
            // 
            this.labelProveedor.AutoSize = true;
            this.labelProveedor.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelProveedor.Location = new System.Drawing.Point(12, 89);
            this.labelProveedor.Name = "labelProveedor";
            this.labelProveedor.Size = new System.Drawing.Size(107, 30);
            this.labelProveedor.TabIndex = 2;
            this.labelProveedor.Text = "Proveedor";
            // 
            // dateTimePickerFechaOrden
            // 
            this.dateTimePickerFechaOrden.Enabled = false;
            this.dateTimePickerFechaOrden.Location = new System.Drawing.Point(178, 16);
            this.dateTimePickerFechaOrden.Name = "dateTimePickerFechaOrden";
            this.dateTimePickerFechaOrden.Size = new System.Drawing.Size(224, 23);
            this.dateTimePickerFechaOrden.TabIndex = 3;
            // 
            // textBoxTotal
            // 
            this.textBoxTotal.Enabled = false;
            this.textBoxTotal.Location = new System.Drawing.Point(178, 58);
            this.textBoxTotal.Name = "textBoxTotal";
            this.textBoxTotal.Size = new System.Drawing.Size(100, 23);
            this.textBoxTotal.TabIndex = 4;
            // 
            // comboBoxProveedor
            // 
            this.comboBoxProveedor.FormattingEnabled = true;
            this.comboBoxProveedor.Location = new System.Drawing.Point(178, 96);
            this.comboBoxProveedor.Name = "comboBoxProveedor";
            this.comboBoxProveedor.Size = new System.Drawing.Size(277, 23);
            this.comboBoxProveedor.TabIndex = 5;
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAgregar.Location = new System.Drawing.Point(568, 15);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(107, 37);
            this.buttonAgregar.TabIndex = 6;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonModificar.Location = new System.Drawing.Point(745, 12);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(119, 40);
            this.buttonModificar.TabIndex = 7;
            this.buttonModificar.Text = "Modificar";
            this.buttonModificar.UseVisualStyleBackColor = true;
            this.buttonModificar.Click += new System.EventHandler(this.buttonModificar_Click);
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonEliminar.Location = new System.Drawing.Point(568, 58);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(107, 37);
            this.buttonEliminar.TabIndex = 8;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // dataGridViewOrden
            // 
            this.dataGridViewOrden.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewOrden.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewOrden.Location = new System.Drawing.Point(12, 125);
            this.dataGridViewOrden.Name = "dataGridViewOrden";
            this.dataGridViewOrden.RowTemplate.Height = 25;
            this.dataGridViewOrden.Size = new System.Drawing.Size(909, 313);
            this.dataGridViewOrden.TabIndex = 9;
            this.dataGridViewOrden.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewOrden_CellClick);
            // 
            // buttonDetalle
            // 
            this.buttonDetalle.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonDetalle.Location = new System.Drawing.Point(745, 58);
            this.buttonDetalle.Name = "buttonDetalle";
            this.buttonDetalle.Size = new System.Drawing.Size(119, 37);
            this.buttonDetalle.TabIndex = 10;
            this.buttonDetalle.Text = "Detalle";
            this.buttonDetalle.UseVisualStyleBackColor = true;
            this.buttonDetalle.Click += new System.EventHandler(this.buttonDetalle_Click);
            // 
            // OrdenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 450);
            this.Controls.Add(this.buttonDetalle);
            this.Controls.Add(this.dataGridViewOrden);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.comboBoxProveedor);
            this.Controls.Add(this.textBoxTotal);
            this.Controls.Add(this.dateTimePickerFechaOrden);
            this.Controls.Add(this.labelProveedor);
            this.Controls.Add(this.labelTotal);
            this.Controls.Add(this.labelFecha);
            this.Name = "OrdenForm";
            this.Text = "Orden";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewOrden)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelFecha;
        private Label labelTotal;
        private Label labelProveedor;
        private DateTimePicker dateTimePickerFechaOrden;
        private TextBox textBoxTotal;
        private ComboBox comboBoxProveedor;
        private Button buttonAgregar;
        private Button buttonModificar;
        private Button buttonEliminar;
        private DataGridView dataGridViewOrden;
        private Button buttonDetalle;
    }
}