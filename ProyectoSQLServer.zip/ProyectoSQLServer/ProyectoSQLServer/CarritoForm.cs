﻿using System.Data;
using System.Data.SqlClient;

namespace ProyectoSQLServer
{
    public partial class CarritoForm : Form
    { 
        List<Cliente> clienteList = new List<Cliente>(); //Lista de clientes
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        long idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 
        long idC = 0; //Variable para id de Carrito para cuando se modificara o eliminara

        public CarritoForm()
        {
            InitializeComponent();
            conectaBD(); //Funcion para hacer la conexion con la base de datos
            //Inicializamos herramientas para el buen uso de nuestro programa
            comboBoxCliente.SelectedIndex = -1;
            comboBoxFormaPago.SelectedIndex = -1;
            textBoxTotal.Text = "0";
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista(); //Funcion que llena la lista 
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT O.Id_Carrito, C.Nombre_Cliente, O.Forma_De_Pago,O.Fecha_Venta,cast(O.Total_Carrito AS DECIMAL(10,2))," +
                "CONCAT( T.Banco, ' | ' ,RIGHT(T.Numero_Tarjeta,4)) FROM Datos.Tarjeta_Cliente T, " +
                "Operaciones.Carrito_Venta O,Usuario.Cliente C WHERE T.Id_Tarjeta=O.Id_Tarjeta_Cliente AND C.Id_Cliente=T.Id_Cliente");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewCarrito.DataSource = null;
            dataGridViewCarrito.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            //Cambiamos los header de el DataGrid
            dataGridViewCarrito.Columns[0].HeaderText = "Id Carrito";
            dataGridViewCarrito.Columns[1].HeaderText = "Nombre Cliente";
            dataGridViewCarrito.Columns[2].HeaderText = "Forma de Pago";
            dataGridViewCarrito.Columns[3].HeaderText = "Fecha Venta";
            dataGridViewCarrito.Columns[4].HeaderText = "Total";
            dataGridViewCarrito.Columns[5].HeaderText = "Banco | Número Tarjeta";
            //dataGridViewCarrito.Columns[6].HeaderText = "Número Tarjeta";
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxTotal.Text = "0"; //Limpiamos textbox de Total
            comboBoxCliente.SelectedIndex = -1; //Ponemos el valor de combobox cliente en default
            comboBoxFormaPago.SelectedIndex = -1; //Ponemos el valor de combobox forma de pago en default
            dateTimePickerFecha.Value = DateTime.Now; //Ponemos fecha del dia actual al datatimepicker
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Usuario.Cliente"); //Sentencia para mostrar todas la tuplas de Cliente

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader(); //Declaramos variable SqlDataReader que llevara la ejecucion del comando
            while (sqlDataReader.Read()) //Leemos lo que nos esntrego la ejecucion del comando
            {
                //Llenamos la lista de clientes que tenemos en la base
                Cliente cliente = new Cliente();
                cliente.Id_Cliente = sqlDataReader.GetInt64(0);
                cliente.Nombre_Cliente = sqlDataReader.GetString(1);
                cliente.Correo_Electronico = sqlDataReader.GetString(2);

                clienteList.Add(cliente);
            }
            comboBoxCliente.DataSource = clienteList; //Le damos valor al combobox cliente
            comboBoxCliente.DisplayMember = "Nombre_Cliente";
            comboBoxCliente.ValueMember = "Id_Cliente";
        }

        private void dataGridViewCarrito_CellClick(object sender, DataGridViewCellEventArgs e) //Evento que se activa cuando hacemos click en una fila del datagrid
            //Y llena las herramientas con los valores de la fila seleccionada
        {
            textBoxTotal.Text = dataGridViewCarrito.CurrentRow.Cells[4].Value.ToString(); //Llenamoos el textbox de total con los datos del datagridview
            dateTimePickerFecha.Value = DateTime.Parse(dataGridViewCarrito.CurrentRow.Cells[3].Value.ToString()); //Llenamos datatimepicker con el valor de datagrid
            idC = Convert.ToInt64(dataGridViewCarrito.CurrentRow.Cells[0].Value.ToString());//Damos valor al id Carrito
            for (int i = 0; i < clienteList.Count; i++)
            {
                if (clienteList[i].Nombre_Cliente == dataGridViewCarrito.CurrentRow.Cells[1].Value.ToString())
                {
                    idA = clienteList[i].Id_Cliente; //Le damos el valor del id del cliente
                }
                if (clienteList[i].Id_Cliente == idA)
                {
                    int id = comboBoxCliente.FindStringExact(clienteList[i].Nombre_Cliente); //Seleccionamos el id del cliente
                    comboBoxCliente.SelectedIndex = id;//Damos valor al combobox
                }
            }
            for (int i = 0; i < comboBoxFormaPago.Items.Count; i++)
            {
                if (dataGridViewCarrito.CurrentRow.Cells[2].Value.ToString() == comboBoxFormaPago.Items[i].ToString())
                {
                    int id = comboBoxFormaPago.FindStringExact(dataGridViewCarrito.CurrentRow.Cells[2].Value.ToString());//Seleccionamos el id de la forma de pago
                    comboBoxFormaPago.SelectedIndex = id; //Damos valor al combobox
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void insertaRegistro()
        {
            try
            {

                conexion.Open();//Abre la conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "INSERT INTO Operaciones.Carrito_Venta" + "(Id_Tarjeta_Cliente, Forma_De_Pago,Fecha_Venta,Total_Carrito) " +
                    "VALUES(" + "(SELECT Id_Tarjeta FROM Datos.Tarjeta_Cliente T WHERE " + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + " = T.Id_Cliente)" + ",'"
                    + comboBoxFormaPago.Text + "','" + fecha + "'," + textBoxTotal.Text + ")";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox

            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error" + ex.Message); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {

                conexion.Open(); //Abrimos conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "UPDATE Operaciones.Carrito_Venta SET Id_Tarjeta_Cliente=" + "(SELECT T.Id_Tarjeta FROM Datos.Tarjeta_Cliente T WHERE  T.Id_Cliente = " 
                    + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + ")" 
                    + ",Forma_De_Pago='" + comboBoxFormaPago.Text.ToString() + "',Fecha_Venta = '" + fecha+ "', Total_Carrito="+textBoxTotal.Text;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error"); //Error en la conexion
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Operaciones.Carrito_Venta WHERE Id_Carrito=" + idC; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        //FUNCIONES PARA ABRIR OTROS FORMS

        private void buttonDetalle_Click(object sender, EventArgs e)
        {
            DetalleCarrito detalleCarrito = new DetalleCarrito();
            detalleCarrito.ShowDialog();
        }

        private void buttonDevolucion_Click(object sender, EventArgs e)
        {
            DevolucionCarrito devolucionCarrito = new DevolucionCarrito();
            devolucionCarrito.ShowDialog();
        }
    }
}
