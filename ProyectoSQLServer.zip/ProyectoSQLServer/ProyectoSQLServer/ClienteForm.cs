﻿using System.Data;
using System.Data.SqlClient;

namespace ProyectoSQLServer
{
    public partial class ClienteForm : Form
    {
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 

        public ClienteForm()
        {
            InitializeComponent();
            conectaBD();
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query = string.Concat("SELECT * FROM Usuario.Cliente"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewCliente.DataSource = null;
            dataGridViewCliente.DataSource = dataTable; //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewCliente.Columns[0].HeaderText = "Id Cliente";
            dataGridViewCliente.Columns[1].HeaderText = "Nombre Cliente";
            dataGridViewCliente.Columns[2].HeaderText = "Correo Electrónico";
            //comboBoxCarrera.
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxNombre.Clear(); //Limpiamos textbox de Nombre
            textBoxCorreo.Clear(); //Limpiamos textbox de Correo
        }

        private void dataGridViewCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewCliente.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            textBoxNombre.Text = dataGridViewCliente.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            textBoxCorreo.Text = dataGridViewCliente.CurrentRow.Cells[2].Value.ToString();//Llenamos el textbox de correo con los datos del datagridview
        }

        //------------------------------------------------------------------------------------------

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                    string consulta = "INSERT INTO Usuario.Cliente" + "(Nombre_Cliente, Correo_Electronico) " +
                        "VALUES('" + textBoxNombre.Text + "','" + textBoxCorreo.Text + "')";
                    //Sentencia para insertar alumnos con los datos de las textbox
                    SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                    command.ExecuteNonQuery(); //Ejecutamos el comando
                    conexion.Close(); //Cerramos conexion
                    limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        //----------------------------------------------------------------------------------------------------------

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "UPDATE Usuario.Cliente SET Nombre_Cliente='" + textBoxNombre.Text + "',Correo_Electronico='"
                    + textBoxCorreo.Text + "' WHERE Id_Cliente=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        //-------------------------------------------------------------------------------------------------------

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Usuario.Cliente WHERE Id_Cliente=" + idA; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonTelefonoCliente_Click(object sender, EventArgs e)
        {
            TelefonoClienteForm telefonoClienteForm = new TelefonoClienteForm();
            telefonoClienteForm.ShowDialog();
        }

        private void buttonTarjeta_Click(object sender, EventArgs e)
        {
            Tarjeta_Cliente tarjeta_Cliente =  new Tarjeta_Cliente();
            tarjeta_Cliente.ShowDialog();
        }
    }
}
