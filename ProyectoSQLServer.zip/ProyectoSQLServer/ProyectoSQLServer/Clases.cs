﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProyectoSQLServer
{
    internal class Clases
    {
    }

    /*
     TarjetaC: Esta clase representa una tarjeta de crédito y tiene las siguientes propiedades:
            Id_Tarjeta: Identificador de la tarjeta (tipo long).
            Id_Cliente: Identificador del cliente asociado a la tarjeta (tipo long).
            Num_Tarjeta: Número de la tarjeta (tipo string).
            CVV: Código de seguridad de la tarjeta (tipo string).
            Banco: Nombre del banco emisor de la tarjeta (tipo string).
            Fecha: Fecha asociada a la tarjeta (tipo DateTime).
            Además, la clase tiene dos constructores: uno vacío y otro que acepta los valores de todas las propiedades.
     */

    public class TarjetaC
    {
        public long Id_Tarjeta { get; set; }
        public long Id_Cliente { get; set; }
        public string Num_Tarjeta { get; set; }
        public string CVV { get; set; }
        public string Banco { get; set; }
        public DateTime Fecha { get; set; }

        public TarjetaC() { }
        public TarjetaC(long id_Tarjeta, long id_Cliente, string num_Tarjeta, string cVV, string banco, DateTime fecha)
        {
            Id_Tarjeta = id_Tarjeta;
            Id_Cliente = id_Cliente;
            Num_Tarjeta = num_Tarjeta;
            CVV = cVV;
            Banco = banco;
            Fecha = fecha;
        }
    }

    /*
        Carrito: Esta clase representa un carrito de compras y contiene las siguientes propiedades:
            Id_Carrito: Identificador del carrito (tipo long).
            Id_Tarjeta: Identificador de la tarjeta asociada al carrito (tipo long).
            FormaPago: Forma de pago utilizada en el carrito (tipo string).
            FechaVenta: Fecha de venta del carrito (tipo DateTime).
            Total: Total de la venta (tipo decimal).
            Cliente: Cliente asociado al carrito (tipo string).
            idynombre: Propiedad de nombre y id juntos (tipo string).
            La clase también tiene dos constructores, uno sin parámetros y otro que acepta los valores de todas las propiedades.
     */

    public class Carrito
    {
        public long Id_Carrito { get; set; }
        public long Id_Tarjeta { get; set; }
        public string FormaPago { get; set; }
        public DateTime FechaVenta { get; set; }
        public decimal Total { get; set; }
        public string Cliente { get; set; }
        public string idynombre { get; set; }

        public Carrito() { }
        public Carrito(long id_Carrito, long id_Tarjeta, string formaPago, DateTime fechaVenta, decimal total, string cliente, string idynombre)
        {
            Id_Carrito = id_Carrito;
            Id_Tarjeta = id_Tarjeta;
            FormaPago = formaPago;
            FechaVenta = fechaVenta;
            Total = total;
            Cliente = cliente;
            this.idynombre = idynombre;
        }
    }

    /*
        Orden: Esta clase representa una orden y tiene las siguientes propiedades:
            Num_Orden: Número de orden (tipo long).
            Id_Producto: Identificador del producto asociado a la orden (tipo long).
            Fecha_Orden: Fecha de la orden (tipo DateTime).
            Total: Total de la orden (tipo decimal).
            Al igual que las clases anteriores, Orden también tiene dos constructores.
     */

    public class Orden
    {
        public long Num_Orden { get; set; }
        public long Id_Producto{ get; set; }
        public DateTime Fecha_Orden { get; set; }
        public decimal Total { get; set; }

        public Orden() { }
        public Orden(long num, long p, DateTime date, int t)
        {
            this.Num_Orden = num;
            this.Id_Producto = p;
            this.Fecha_Orden = date;
            this.Total = t;
        }
    }

    /*
        Producto: Esta clase representa una orden y tiene las siguientes propiedades:
            Id_Producto: Identificador del producto (tipo long).
            Nombre_Producto: Nombre del producto (tipo string).
            Precio_Publico_Producto: Precio público del producto (tipo decimal).
            Precio_Proveedor_Producto: Precio proveedor del producto (tipo decimal).
            Color: Color del producto (tipo string).
            Stock: Cantidad en stock del producto (tipo int).
            Al igual que las clases anteriores, Producto también tiene dos constructores. 
     */

    public class Producto
    {
        public long Id_Producto { get; set; }
        public string Nombre_Producto { get; set; }
        public decimal Precio_Publico_Producto { get; set; }
        public decimal Precio_Proveedor_Producto { get; set; }
        public string Color { get; set; }
        public int Stock { get; set; }

        public Producto() { }
        public Producto(long Id, string Nombre, int PPublicoP, int PProveedorP, string c, int s)
        {
            this.Id_Producto = Id;
            this.Nombre_Producto = Nombre;
            this.Precio_Publico_Producto = PPublicoP;
            this.Precio_Proveedor_Producto = PProveedorP;
            this.Color = c;
            this.Stock = s;
        }
    }

    /*
     Cliente: Esta clase representa un cliente y tiene las siguientes propiedades:
        Id_Cliente: Identificador del cliente (tipo long).
        Nombre_Cliente: Nombre del cliente (tipo string).
        Correo_Electronico: Correo electrónico del cliente (tipo string).
        tarjeta: Objeto de tipo Tarjeta que representa la tarjeta asociada
     */

    public class Cliente
    {
        public long Id_Cliente { get; set; }
        public string Nombre_Cliente { get; set; }
        public string Correo_Electronico { get; set; }
        public Tarjeta tarjeta { get; set; }

        public Cliente() { }
        public Cliente(long Id, string Nombre, string Correo, Tarjeta tarjeta)
        {
            this.Id_Cliente = Id;
            this.Nombre_Cliente = Nombre;
            this.Correo_Electronico = Correo;
            this.tarjeta = tarjeta;
        }
    }

    /*
    Proveedor: Esta clase representa un proveedor y contiene las siguientes propiedades:
        Id_Proveedor: Identificador del proveedor (tipo long).
        Nombre_Proveedor: Nombre del proveedor (tipo string).
        Correo_Electronico: Correo electrónico del proveedor (tipo string).
        Domicilio_Fiscal: Domicilio fiscal del proveedor (tipo string).
        La clase Proveedor también tiene dos constructores, uno sin parámetros y otro que acepta los valores de todas las propiedades.
     */

    public class Proveedor
    {
        public long Id_Proveedor { get; set; }
        public string Nombre_Proveedor { get; set; }
        public string Correo_Electronico { get; set; }
        public string Domicilio_Fiscal { get; set; }

        public Proveedor() { }
        public Proveedor(long Id, string Nombre, string Correo, string Domicilio)
        {
            this.Id_Proveedor = Id;
            this.Nombre_Proveedor = Nombre;
            this.Correo_Electronico = Correo;
            this.Domicilio_Fiscal = Domicilio;
        }
    }

    /*
     Tarjeta: Esta clase representa una tarjeta de crédito y tiene las siguientes propiedades:
        Id_Tarjeta: Identificador de la tarjeta (tipo long).
        Id_Cliente: Identificador del cliente asociado a la tarjeta (tipo long).
        Numero_Tarjeta: Número de la tarjeta (tipo long).
        CVV: Código de seguridad de la tarjeta (tipo string).
        Banco: Nombre del banco emisor de la tarjeta (tipo string).
        Fecha: Fecha asociada a la tarjeta (tipo DateTime).
        La clase Tarjeta también tiene dos constructores, uno sin parámetros y otro que acepta los valores de todas las propiedades.
     */

    public class Tarjeta
    {
        public long Id_Tarjeta { get; set; }
        public long Id_Cliente { get; set; }
        public long Numero_Tarjeta { get; set; }
        public string CVV { get; set; }
        public string Banco { get; set; }
        public DateTime Fecha { get; set; }

        public Tarjeta() { }
        public Tarjeta(long id_Tarjeta, long id_Cliente, long numero_Tarjeta, string cVV, string banco, DateTime fecha)
        {
            Id_Tarjeta = id_Tarjeta;
            Id_Cliente = id_Cliente;
            Numero_Tarjeta = numero_Tarjeta;
            CVV = cVV;
            Banco = banco;
            Fecha = fecha;
        }
    }
}
