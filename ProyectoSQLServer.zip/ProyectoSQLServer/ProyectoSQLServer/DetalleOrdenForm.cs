﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{
    public partial class DetalleOrdenForm : Form
    {
        List<Producto> productoList = new List<Producto>();
        List<Orden> ordenList = new List<Orden>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 
        long idP = 0;
        int idO = 0;

        public DetalleOrdenForm()
        {
            InitializeComponent();
            conexion.Open(); //Abrimos conexion con la base de datos 
            llenalista();//Funcion que muestra en el datagridview las tuplas
            conexion.Close();
            conectaBD();
            //Inicializamos herramientas para el buen uso de nuestro programa
            comboBoxOrden.SelectedIndex = -1;
            comboBoxProducto.SelectedIndex = -1;
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT O.Num_Orden, D.Cantidad,cast(D.SubTotal AS DECIMAL(10,2)),CONCAT( P.Nombre_Producto, ' | ' ,cast(P.Precio_Publico_Proveedor AS DECIMAL(10,2))) " +
                "FROM Operaciones.Orden O,Operaciones.Detalle_Orden D,Articulo.Producto P " +
                "WHERE O.Num_Orden = D.Num_Orden AND D.Id_Producto = P.Id_Producto");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewDetalleOrden.DataSource = null;
            dataGridViewDetalleOrden.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewDetalleOrden.Columns[0].HeaderText = "Número Orden";
            dataGridViewDetalleOrden.Columns[1].HeaderText = "Cantidad";
            dataGridViewDetalleOrden.Columns[2].HeaderText = "SubTotal";
            dataGridViewDetalleOrden.Columns[3].HeaderText = "Nombre Producto | Precio Proveedor";
            //dataGridViewDetalleOrden.Columns[4].HeaderText = "Precio Proveedor";
            OrdenForm ordenForm = Application.OpenForms.OfType<OrdenForm>().FirstOrDefault();
            if(ordenForm != null)
                ordenForm.muestra();
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            //Limpiamos herramientas para el buen uso de nuestro programa
            textBoxCantidad.Clear();
            comboBoxOrden.SelectedIndex = -1;
            comboBoxProducto.SelectedIndex = -1;
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Articulo.Producto"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            //Llenamos lista de Productos
            while (sqlDataReader.Read())
            {
                Producto producto = new Producto();
                producto.Id_Producto = sqlDataReader.GetInt64(0);
                producto.Nombre_Producto = sqlDataReader.GetString(1) + " | " + Math.Round(sqlDataReader.GetDecimal(3),2);
                producto.Precio_Publico_Producto = sqlDataReader.GetDecimal(2);
                //producto.Precio_Proveedor_Producto = sqlDataReader.GetDecimal(3);
                producto.Color = sqlDataReader.GetString(4);

                productoList.Add(producto);
            }
            comboBoxProducto.DataSource = productoList;
            comboBoxProducto.DisplayMember = "Nombre_Producto";
            comboBoxProducto.ValueMember = "Id_Producto";

            query = string.Concat("SELECT * FROM Operaciones.Orden"); //Sentencia para mostrar todas la tuplas

            sqlDataReader.Close();
            command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            sqlDataReader = command.ExecuteReader();
            //Llenamos lista de ordenes
            while (sqlDataReader.Read())
            {
                Orden orden = new Orden();
                orden.Num_Orden = sqlDataReader.GetInt64(0);
                orden.Id_Producto = sqlDataReader.GetInt64(1);
                orden.Fecha_Orden = sqlDataReader.GetDateTime(2);
                orden.Total = sqlDataReader.GetDecimal(3);

                ordenList.Add(orden);
            }
            comboBoxOrden.DataSource = ordenList;
            comboBoxOrden.DisplayMember = "Num_Orden";
            comboBoxOrden.ValueMember = "Num_Orden";
        }

        private void dataGridViewDetalleOrden_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewDetalleOrden.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Nombre_Producto == dataGridViewDetalleOrden.CurrentRow.Cells[3].Value.ToString())
                {
                    idP = productoList[i].Id_Producto; //Agregamos id de producto
                    break;
                }
            }
            textBoxCantidad.Text = dataGridViewDetalleOrden.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            for (int i = 0; i < ordenList.Count; i++)
            {
                if (ordenList[i].Num_Orden == idA)
                {
                    int id = comboBoxOrden.FindStringExact(ordenList[i].Num_Orden.ToString());
                    comboBoxOrden.SelectedIndex = id; //Seleccionamos el valor en el combobox
                    break;
                }
            }
            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Id_Producto == idP)
                {
                    int id = comboBoxProducto.FindStringExact(productoList[i].Nombre_Producto);
                    comboBoxProducto.SelectedIndex = id; //Seleccionamos el valor en el combobox
                    break;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string consulta = "INSERT INTO Operaciones.Detalle_Orden" + "(Num_Orden, Id_Producto,Cantidad) " +
                    "VALUES(" + ordenList[comboBoxOrden.SelectedIndex].Num_Orden + "," + productoList[comboBoxProducto.SelectedIndex].Id_Producto + "," + textBoxCantidad.Text + ")";
                //Sentencia para insertar detalles con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: " + ex.Message ); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "UPDATE Operaciones.Detalle_Orden SET Num_Orden=" + ordenList[comboBoxOrden.SelectedIndex].Num_Orden + ",Id_Producto="
                    + productoList[comboBoxProducto.SelectedIndex].Id_Producto + ",Cantidad=" + textBoxCantidad.Text + " WHERE Num_Orden=" + idA + " AND Id_Producto=" + idP;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero Duplicado de Tarjeta"); //Error en la conexion

            }


        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Operaciones.Detalle_Orden WHERE Num_Orden=" + idA + "AND Id_Producto=" + idP; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
