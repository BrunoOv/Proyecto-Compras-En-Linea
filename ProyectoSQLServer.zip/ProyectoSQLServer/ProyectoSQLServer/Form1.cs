namespace ProyectoSQLServer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCliente_Click(object sender, EventArgs e)
        {
            ClienteForm clienteForm = new ClienteForm();
            clienteForm.ShowDialog();
        }

        private void buttonProveedor_Click(object sender, EventArgs e)
        {
            ProveedorForm proveedorForm = new ProveedorForm();
            proveedorForm.ShowDialog();
        }

        private void buttonProducto_Click(object sender, EventArgs e)
        {
            ProductoForm productoForm = new ProductoForm();
            productoForm.ShowDialog();
        }

        private void buttonOrden_Click(object sender, EventArgs e)
        {
            OrdenForm ordenForm = new OrdenForm();
            ordenForm.ShowDialog();
        }

        private void buttonCarrito_Click(object sender, EventArgs e)
        {
            CarritoForm carritoForm = new CarritoForm();
            carritoForm.ShowDialog();
        }
    }
}