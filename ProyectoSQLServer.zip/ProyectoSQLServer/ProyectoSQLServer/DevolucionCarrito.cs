﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{
    public partial class DevolucionCarrito : Form
    {
        List<Producto> productoList = new List<Producto>();
        List<Carrito> carritoList = new List<Carrito>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 
        long idP = 0;
        int conecta = 0;

        string query ; //Sentencia para mostrar todas la tuplas

        public DevolucionCarrito()
        {
            InitializeComponent();
            conectaBD();
            comboBoxProducto.SelectedIndex = -1;
            dateTimePickerFecha.Value = DateTime.Now;
            textBoxCantidad.Clear();
            //comboBoxProducto.Enabled = false;
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista();
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT C.Id_Carrito, D.Cantidad_Producto, D.Fecha, CONCAT( P.Nombre_Producto, ' | ',cast(P.Precio_Publico_Producto AS DECIMAL(10,2))) " +
                "FROM Articulo.Producto P,Operaciones.Carrito_Venta C, Operaciones.Devolucion_Carrito D " +
                "WHERE C.Id_Carrito = D.Id_Carrito AND D.Id_Producto = P.Id_Producto");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewDevolucion.DataSource = null;
            dataGridViewDevolucion.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewDevolucion.Columns[0].HeaderText = "Id Carrito";
            dataGridViewDevolucion.Columns[1].HeaderText = "Cantidad";
            dataGridViewDevolucion.Columns[2].HeaderText = "Fecha";
            dataGridViewDevolucion.Columns[3].HeaderText = "Nombre Producto | Precio Publico Producto";
            //dataGridViewDevolucion.Columns[4].HeaderText = "Precio Publico Producto";
            CarritoForm carritoForm = Application.OpenForms.OfType<CarritoForm>().FirstOrDefault();
            if (carritoForm != null)
                carritoForm.muestra();
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            comboBoxProducto.SelectedIndex = -1;
            dateTimePickerFecha.Value = DateTime.Now;
            textBoxCantidad.Clear();
        }

        public void llenalista()
        {
            SqlCommand command; //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader;
            query = string.Concat("SELECT C.Id_Carrito, C.Id_Tarjeta_Cliente, C.Forma_De_Pago, C.Fecha_Venta, C.Total_Carrito, U.Nombre_Cliente" +
                " FROM Operaciones.Carrito_Venta C, Datos.Tarjeta_Cliente T, Usuario.Cliente U " +
                "WHERE T.Id_Cliente = U.Id_Cliente AND T.Id_Tarjeta = C.Id_Tarjeta_Cliente"); //Sentencia para mostrar todas la tuplas


            
            command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            sqlDataReader = command.ExecuteReader();
            //Llenamos lista de carrito
            while (sqlDataReader.Read())
            {
                Carrito carrito = new Carrito();
                carrito.Id_Carrito = sqlDataReader.GetInt64(0);
                carrito.Id_Tarjeta = sqlDataReader.GetInt64(1);
                carrito.FormaPago = sqlDataReader.GetString(2);
                carrito.FechaVenta = sqlDataReader.GetDateTime(3);
                carrito.Total = sqlDataReader.GetDecimal(4);
                carrito.Cliente = sqlDataReader.GetString(5);
                carrito.idynombre = carrito.Id_Carrito + " - " + carrito.Cliente;

                carritoList.Add(carrito);
            }
            sqlDataReader.Close();
            comboBoxCarrito.DataSource = carritoList;
            comboBoxCarrito.DisplayMember = "idynombre";
            comboBoxCarrito.ValueMember = "idynombre";

        }

        private void dataGridViewDevolucion_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string g = dataGridViewDevolucion.CurrentRow.Cells[0].Value.ToString();
            string idCa = "";
            for (int i = 0; i < g.Length; i++)
            {
                if (g[i] != ' ')
                {
                    idCa += g[i]; //Separamos el id de todo el string
                } 
                else
                    break;
            }

            idA = int.Parse(idCa); //Indicamos el id de la tupla que seleccionamos
            conexion.Open();
            query = string.Concat("SELECT * "
                + " FROM Articulo.Producto P, Operaciones.Detalle_Carrito O"
                + " WHERE P.Id_Producto = O.Id_Producto AND O.Id_Carrito = " + idA); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader1 = command.ExecuteReader();
            productoList.Clear();
            comboBoxProducto.DataSource = null;
            string q = sqlDataReader1.ToString();

            
            while (sqlDataReader1.Read())
            {
                Producto producto = new Producto();
                producto.Id_Producto = sqlDataReader1.GetInt64(0);
                producto.Nombre_Producto = sqlDataReader1.GetString(1) + " | " + Math.Round(sqlDataReader1.GetDecimal(2), 2);

                productoList.Add(producto);
            }


            sqlDataReader1.Close();
            conexion.Close();


            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Nombre_Producto == dataGridViewDevolucion.CurrentRow.Cells[3].Value.ToString())
                {
                    idP = productoList[i].Id_Producto; //Indicamos el di del producto seleccionado
                    break;
                }
            }
            textBoxCantidad.Text = dataGridViewDevolucion.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de cantidad con los datos del datagridview
            dateTimePickerFecha.Value = DateTime.Parse(dataGridViewDevolucion.CurrentRow.Cells[2].Value.ToString());
            for (int i = 0; i < carritoList.Count; i++)
            {
                if (carritoList[i].Id_Carrito == idA)
                {
                    int id = comboBoxCarrito.FindString(carritoList[i].Id_Carrito.ToString());
                    comboBoxCarrito.SelectedIndex = id; //Damos valor a el combobox
                    break;
                }
            }
            for (int i = 0; i < productoList.Count; i++)
            {
                if (productoList[i].Id_Producto == idP)
                {
                    int id = comboBoxProducto.FindStringExact(productoList[i].Nombre_Producto);
                    comboBoxProducto.SelectedIndex = id; //Damos el valor al combobox
                    break;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                //"(SELECT Producto FROM Operaciones.Detalle_Carrito DC, Operaciones.Devolucion_Carrito CD WHERE DC.Id_Carrito = CD.Id_Carrito)"
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "INSERT INTO Operaciones.Devolucion_Carrito (Id_Carrito, Id_Producto, Fecha, Cantidad_Producto) " +
                    "VALUES(" + carritoList[comboBoxCarrito.SelectedIndex].Id_Carrito + "," + productoList[comboBoxProducto.SelectedIndex].Id_Producto + ",'" + fecha +
                    "','" + textBoxCantidad.Text + "')";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "UPDATE Operaciones.Devolucion_Carrito SET Id_Carrito=" + carritoList[comboBoxCarrito.SelectedIndex].Id_Carrito + ",Id_Producto="
                    + productoList[comboBoxProducto.SelectedIndex].Id_Producto + ",Cantidad_Producto=" + textBoxCantidad.Text + ", Fecha='" + fecha +
                    "' WHERE Id_Carrito=" + idA + " AND Id_Producto=" + idP;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero Duplicado de Tarjeta"); //Error en la conexion

            }


        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "DELETE Operaciones.Devolucion_Carrito WHERE Id_Carrito=" + idA + "AND Id_Producto=" + idP  + "AND Cantidad_Producto=" +
                    textBoxCantidad.Text + "AND Fecha ='" + fecha +  "'"; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void comboBoxCarrito_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (conecta == 0)
            {
                conecta++;
            }
            else
            {
                comboBoxProducto.Enabled = true;
                conexion.Open();
                string g = comboBoxCarrito.Text;
                string idCa = "";
                for (int i = 0; i < g.Length; i++)
                {
                    if (g[i] != ' ')
                    {
                        idCa += g[i];
                    }
                    else
                        break;
                }

                idA = int.Parse(idCa);
                SqlCommand command; //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
                comboBoxProducto.Enabled = true;

                query = string.Concat("SELECT * "
                + " FROM Articulo.Producto P, Operaciones.Detalle_Carrito O"
                + " WHERE P.Id_Producto = O.Id_Producto AND O.Id_Carrito = " + idA); //Sentencia para mostrar todas la tuplas

                command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
                SqlDataReader sqlDataReader1 = command.ExecuteReader();
                productoList.Clear();
                comboBoxProducto.DataSource = null;
                string q = sqlDataReader1.ToString();
                while (sqlDataReader1.Read())
                {
                    Producto producto = new Producto();
                    producto.Id_Producto = sqlDataReader1.GetInt64(0);
                    producto.Nombre_Producto = sqlDataReader1.GetString(1) + " | " + Math.Round(sqlDataReader1.GetDecimal(2), 2);

                    productoList.Add(producto);
                }
                comboBoxProducto.DataSource = productoList;
                comboBoxProducto.DisplayMember = "Nombre_Producto";
                comboBoxProducto.ValueMember = "Id_Producto";

                sqlDataReader1.Close();
                conexion.Close();
            }
        }
    }
}
