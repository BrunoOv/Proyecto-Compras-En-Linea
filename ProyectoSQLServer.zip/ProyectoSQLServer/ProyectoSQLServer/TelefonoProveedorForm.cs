﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{

    public partial class TelefonoProveedorForm : Form
    {
        List<Proveedor> proveedors = new List<Proveedor>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 

        public TelefonoProveedorForm()
        {
            InitializeComponent();
            conectaBD();
            comboBoxProveedor.SelectedIndex = -1;
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista();
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT T.Id_Proveedor, T.Numero, CONCAT(P.Nombre_Proveedor,' | ' ,P.Correo_Electronico) FROM Usuario.Proveedor P, " +
                "Datos.Telefono_Proveedor T WHERE P.Id_Proveedor=T.Id_Proveedor");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewTelefonoP.DataSource = null;
            dataGridViewTelefonoP.DataSource = dataTable;//Llenamos el dataGrid con los valores de las tuplas
            dataGridViewTelefonoP.Columns[0].HeaderText = "Id Proveedor";
            dataGridViewTelefonoP.Columns[1].HeaderText = "Número";
            dataGridViewTelefonoP.Columns[2].HeaderText = "Nombre Proveedor | Correo Electrónico";
            //dataGridViewTelefonoP.Columns[3].HeaderText = "Correo Electrónico";
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxNumero.Clear(); //Limpiamos textbox de Nombre
            comboBoxProveedor.SelectedIndex = -1; //Limpiamos textbox de Correo
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Usuario.Proveedor"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Proveedor proveedor = new Proveedor();
                proveedor.Id_Proveedor = sqlDataReader.GetInt64(0);
                proveedor.Nombre_Proveedor = sqlDataReader.GetString(2) + " | " + sqlDataReader.GetString(1);
                //proveedor.Correo_Electronico = sqlDataReader.GetString(1);
                proveedor.Domicilio_Fiscal = sqlDataReader.GetString(3);

                proveedors.Add(proveedor);
            }
            comboBoxProveedor.DataSource = proveedors;
            comboBoxProveedor.DisplayMember = "Nombre_Proveedor";
            comboBoxProveedor.ValueMember = "Id_Proveedor";
        }

        private void dataGridViewTelefonoP_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewTelefonoP.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            textBoxNumero.Text = dataGridViewTelefonoP.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            //comboBoxCliente.SelectedIndex = dataGridViewTelefonoC.CurrentRow.Cells[3].Value.ToString();//Llenamos el textbox de correo con los datos del datagridview
            for (int i = 0; i < proveedors.Count; i++)
            {
                if (proveedors[i].Id_Proveedor == idA)
                {
                    int id = comboBoxProveedor.FindStringExact(proveedors[i].Nombre_Proveedor);
                    comboBoxProveedor.SelectedIndex = id;
                    break;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string consulta = "INSERT INTO Datos.Telefono_Proveedor" + "(Id_Proveedor, Numero) " +
                    "VALUES(" + proveedors[comboBoxProveedor.SelectedIndex].Id_Proveedor + ",'" + textBoxNumero.Text + "')";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero duplicado"); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "UPDATE Datos.Telefono_Proveedor SET Id_Proveedor=" + proveedors[comboBoxProveedor.SelectedIndex].Id_Proveedor + ",Numero='"
                    + textBoxNumero.Text + "' WHERE Id_Proveedor=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero duplicado"); //Error en la conexion
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Datos.Telefono_Proveedor WHERE Id_Proveedor=" + idA + "AND Numero=" + textBoxNumero.Text; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
