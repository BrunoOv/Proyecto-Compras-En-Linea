﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{
    public partial class ProductoForm : Form
    {
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Producto para cuando se modificara o eliminara 

        public ProductoForm()
        {
            InitializeComponent();
            conectaBD();
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                return -1;
            }
        }

        public void muestra()
        {
            string query = string.Concat("SELECT Id_Producto,Nombre_Producto,cast(Precio_Publico_Producto AS DECIMAL(10,2)), cast(Precio_Publico_Proveedor AS DECIMAL(10,2)), " +
                "Color, Stock FROM Articulo.Producto"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewProducto.DataSource = null;
            dataGridViewProducto.DataSource = dataTable; //Llenamos el dataGrid con los valores de las tuplasdataGridViewProveedor.Columns[0].HeaderText = "Id Proveedor";
            dataGridViewProducto.Columns[0].HeaderText = "Id Producto";
            dataGridViewProducto.Columns[1].HeaderText = "Nombre Producto";
            dataGridViewProducto.Columns[2].HeaderText = "Precio Público Producto";
            dataGridViewProducto.Columns[3].HeaderText = "Precio Público Proveedor";
            dataGridViewProducto.Columns[4].HeaderText = "Color";
            dataGridViewProducto.Columns[5].HeaderText = "Stock";
            //comboBoxCarrera.
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxNombre.Clear(); //Limpiamos textbox de Nombre
            textBoxPrecioPublico.Clear(); //Limpiamos textbox
            textBoxPrecioProveedor.Clear();
            textBoxColor.Clear();
            textBoxStock.Clear();
        }


        private void dataGridViewProducto_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewProducto.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            textBoxNombre.Text = dataGridViewProducto.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            textBoxPrecioPublico.Text = (decimal.Round(Convert.ToDecimal(dataGridViewProducto.CurrentRow.Cells[2].Value), 2)).ToString();
            textBoxPrecioProveedor.Text = (decimal.Round(Convert.ToDecimal(dataGridViewProducto.CurrentRow.Cells[3].Value), 2)).ToString();
            textBoxColor.Text = dataGridViewProducto.CurrentRow.Cells[4].Value.ToString();
            textBoxStock.Text = dataGridViewProducto.CurrentRow.Cells[5].Value.ToString();
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string consulta = "INSERT INTO Articulo.Producto" + 
                    "(Nombre_Producto, Precio_Publico_Producto, Precio_Publico_Proveedor,Color,Stock) " + 
                    "VALUES('" + textBoxNombre.Text + "','" + textBoxPrecioPublico.Text + "','" + textBoxPrecioProveedor.Text 
                    + "','" + textBoxColor.Text + "'," + textBoxStock.Text + ")";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string s = textBoxStock.Text;
                string consulta = "UPDATE Articulo.Producto SET Nombre_Producto='" + textBoxNombre.Text + "',Precio_Publico_Producto='"
                    + textBoxPrecioPublico.Text + "',Precio_Publico_Proveedor='" + textBoxPrecioProveedor.Text 
                    + "',Color='" + textBoxColor.Text + "',Stock=" + textBoxStock.Text + " WHERE Id_Producto=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Articulo.Producto WHERE Id_Producto=" + idA; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
