﻿namespace ProyectoSQLServer
{
    partial class ProductoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelNombre = new System.Windows.Forms.Label();
            this.labelPrecioPublico = new System.Windows.Forms.Label();
            this.labelPrecioProveedor = new System.Windows.Forms.Label();
            this.labelColor = new System.Windows.Forms.Label();
            this.labelStock = new System.Windows.Forms.Label();
            this.textBoxNombre = new System.Windows.Forms.TextBox();
            this.textBoxPrecioPublico = new System.Windows.Forms.TextBox();
            this.textBoxPrecioProveedor = new System.Windows.Forms.TextBox();
            this.textBoxColor = new System.Windows.Forms.TextBox();
            this.textBoxStock = new System.Windows.Forms.TextBox();
            this.dataGridViewProducto = new System.Windows.Forms.DataGridView();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducto)).BeginInit();
            this.SuspendLayout();
            // 
            // labelNombre
            // 
            this.labelNombre.AutoSize = true;
            this.labelNombre.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelNombre.Location = new System.Drawing.Point(10, 7);
            this.labelNombre.Name = "labelNombre";
            this.labelNombre.Size = new System.Drawing.Size(94, 30);
            this.labelNombre.TabIndex = 0;
            this.labelNombre.Text = "Nombre";
            // 
            // labelPrecioPublico
            // 
            this.labelPrecioPublico.AutoSize = true;
            this.labelPrecioPublico.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelPrecioPublico.Location = new System.Drawing.Point(10, 35);
            this.labelPrecioPublico.Name = "labelPrecioPublico";
            this.labelPrecioPublico.Size = new System.Drawing.Size(149, 30);
            this.labelPrecioPublico.TabIndex = 1;
            this.labelPrecioPublico.Text = "Precio Público";
            // 
            // labelPrecioProveedor
            // 
            this.labelPrecioProveedor.AutoSize = true;
            this.labelPrecioProveedor.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelPrecioProveedor.Location = new System.Drawing.Point(10, 64);
            this.labelPrecioProveedor.Name = "labelPrecioProveedor";
            this.labelPrecioProveedor.Size = new System.Drawing.Size(181, 30);
            this.labelPrecioProveedor.TabIndex = 2;
            this.labelPrecioProveedor.Text = "Precio Proveedor";
            // 
            // labelColor
            // 
            this.labelColor.AutoSize = true;
            this.labelColor.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelColor.Location = new System.Drawing.Point(10, 92);
            this.labelColor.Name = "labelColor";
            this.labelColor.Size = new System.Drawing.Size(66, 30);
            this.labelColor.TabIndex = 3;
            this.labelColor.Text = "Color";
            // 
            // labelStock
            // 
            this.labelStock.AutoSize = true;
            this.labelStock.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelStock.Location = new System.Drawing.Point(10, 121);
            this.labelStock.Name = "labelStock";
            this.labelStock.Size = new System.Drawing.Size(65, 30);
            this.labelStock.TabIndex = 4;
            this.labelStock.Text = "Stock";
            // 
            // textBoxNombre
            // 
            this.textBoxNombre.Location = new System.Drawing.Point(120, 13);
            this.textBoxNombre.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxNombre.Name = "textBoxNombre";
            this.textBoxNombre.Size = new System.Drawing.Size(518, 23);
            this.textBoxNombre.TabIndex = 5;
            // 
            // textBoxPrecioPublico
            // 
            this.textBoxPrecioPublico.Location = new System.Drawing.Point(185, 41);
            this.textBoxPrecioPublico.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxPrecioPublico.Name = "textBoxPrecioPublico";
            this.textBoxPrecioPublico.Size = new System.Drawing.Size(141, 23);
            this.textBoxPrecioPublico.TabIndex = 6;
            // 
            // textBoxPrecioProveedor
            // 
            this.textBoxPrecioProveedor.Location = new System.Drawing.Point(216, 72);
            this.textBoxPrecioProveedor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxPrecioProveedor.Name = "textBoxPrecioProveedor";
            this.textBoxPrecioProveedor.Size = new System.Drawing.Size(110, 23);
            this.textBoxPrecioProveedor.TabIndex = 7;
            // 
            // textBoxColor
            // 
            this.textBoxColor.Location = new System.Drawing.Point(88, 100);
            this.textBoxColor.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxColor.Name = "textBoxColor";
            this.textBoxColor.Size = new System.Drawing.Size(238, 23);
            this.textBoxColor.TabIndex = 8;
            // 
            // textBoxStock
            // 
            this.textBoxStock.Location = new System.Drawing.Point(88, 129);
            this.textBoxStock.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.textBoxStock.Name = "textBoxStock";
            this.textBoxStock.Size = new System.Drawing.Size(110, 23);
            this.textBoxStock.TabIndex = 9;
            // 
            // dataGridViewProducto
            // 
            this.dataGridViewProducto.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewProducto.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProducto.Location = new System.Drawing.Point(10, 154);
            this.dataGridViewProducto.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataGridViewProducto.Name = "dataGridViewProducto";
            this.dataGridViewProducto.RowHeadersWidth = 51;
            this.dataGridViewProducto.RowTemplate.Height = 29;
            this.dataGridViewProducto.Size = new System.Drawing.Size(899, 175);
            this.dataGridViewProducto.TabIndex = 10;
            this.dataGridViewProducto.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewProducto_CellClick);
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAgregar.Location = new System.Drawing.Point(652, 7);
            this.buttonAgregar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(109, 44);
            this.buttonAgregar.TabIndex = 11;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonModificar.Location = new System.Drawing.Point(777, 7);
            this.buttonModificar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(132, 41);
            this.buttonModificar.TabIndex = 12;
            this.buttonModificar.Text = "Modificar";
            this.buttonModificar.UseVisualStyleBackColor = true;
            this.buttonModificar.Click += new System.EventHandler(this.buttonModificar_Click);
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Font = new System.Drawing.Font("Segoe UI", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonEliminar.Location = new System.Drawing.Point(720, 64);
            this.buttonEliminar.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(121, 40);
            this.buttonEliminar.TabIndex = 13;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // ProductoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(920, 338);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.dataGridViewProducto);
            this.Controls.Add(this.textBoxStock);
            this.Controls.Add(this.textBoxColor);
            this.Controls.Add(this.textBoxPrecioProveedor);
            this.Controls.Add(this.textBoxPrecioPublico);
            this.Controls.Add(this.textBoxNombre);
            this.Controls.Add(this.labelStock);
            this.Controls.Add(this.labelColor);
            this.Controls.Add(this.labelPrecioProveedor);
            this.Controls.Add(this.labelPrecioPublico);
            this.Controls.Add(this.labelNombre);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "ProductoForm";
            this.Text = "Producto";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProducto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelNombre;
        private Label labelPrecioPublico;
        private Label labelPrecioProveedor;
        private Label labelColor;
        private Label labelStock;
        private TextBox textBoxNombre;
        private TextBox textBoxPrecioPublico;
        private TextBox textBoxPrecioProveedor;
        private TextBox textBoxColor;
        private TextBox textBoxStock;
        private DataGridView dataGridViewProducto;
        private Button buttonAgregar;
        private Button buttonModificar;
        private Button buttonEliminar;
    }
}