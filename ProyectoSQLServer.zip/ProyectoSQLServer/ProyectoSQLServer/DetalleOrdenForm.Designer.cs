﻿namespace ProyectoSQLServer
{
    partial class DetalleOrdenForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelCantidad = new System.Windows.Forms.Label();
            this.labelOrden = new System.Windows.Forms.Label();
            this.labelProducto = new System.Windows.Forms.Label();
            this.textBoxCantidad = new System.Windows.Forms.TextBox();
            this.comboBoxOrden = new System.Windows.Forms.ComboBox();
            this.comboBoxProducto = new System.Windows.Forms.ComboBox();
            this.dataGridViewDetalleOrden = new System.Windows.Forms.DataGridView();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.buttonModificar = new System.Windows.Forms.Button();
            this.buttonEliminar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleOrden)).BeginInit();
            this.SuspendLayout();
            // 
            // labelCantidad
            // 
            this.labelCantidad.AutoSize = true;
            this.labelCantidad.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelCantidad.Location = new System.Drawing.Point(12, 91);
            this.labelCantidad.Name = "labelCantidad";
            this.labelCantidad.Size = new System.Drawing.Size(96, 30);
            this.labelCantidad.TabIndex = 0;
            this.labelCantidad.Text = "Cantidad";
            // 
            // labelOrden
            // 
            this.labelOrden.AutoSize = true;
            this.labelOrden.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelOrden.Location = new System.Drawing.Point(12, 48);
            this.labelOrden.Name = "labelOrden";
            this.labelOrden.Size = new System.Drawing.Size(71, 30);
            this.labelOrden.TabIndex = 2;
            this.labelOrden.Text = "Orden";
            // 
            // labelProducto
            // 
            this.labelProducto.AutoSize = true;
            this.labelProducto.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.labelProducto.Location = new System.Drawing.Point(12, 9);
            this.labelProducto.Name = "labelProducto";
            this.labelProducto.Size = new System.Drawing.Size(97, 30);
            this.labelProducto.TabIndex = 3;
            this.labelProducto.Text = "Producto";
            // 
            // textBoxCantidad
            // 
            this.textBoxCantidad.Location = new System.Drawing.Point(114, 98);
            this.textBoxCantidad.Name = "textBoxCantidad";
            this.textBoxCantidad.Size = new System.Drawing.Size(100, 23);
            this.textBoxCantidad.TabIndex = 4;
            // 
            // comboBoxOrden
            // 
            this.comboBoxOrden.FormattingEnabled = true;
            this.comboBoxOrden.Location = new System.Drawing.Point(114, 55);
            this.comboBoxOrden.Name = "comboBoxOrden";
            this.comboBoxOrden.Size = new System.Drawing.Size(191, 23);
            this.comboBoxOrden.TabIndex = 6;
            // 
            // comboBoxProducto
            // 
            this.comboBoxProducto.FormattingEnabled = true;
            this.comboBoxProducto.Location = new System.Drawing.Point(114, 18);
            this.comboBoxProducto.Name = "comboBoxProducto";
            this.comboBoxProducto.Size = new System.Drawing.Size(193, 23);
            this.comboBoxProducto.TabIndex = 7;
            // 
            // dataGridViewDetalleOrden
            // 
            this.dataGridViewDetalleOrden.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewDetalleOrden.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDetalleOrden.Location = new System.Drawing.Point(12, 138);
            this.dataGridViewDetalleOrden.Name = "dataGridViewDetalleOrden";
            this.dataGridViewDetalleOrden.RowTemplate.Height = 25;
            this.dataGridViewDetalleOrden.Size = new System.Drawing.Size(776, 300);
            this.dataGridViewDetalleOrden.TabIndex = 8;
            this.dataGridViewDetalleOrden.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewDetalleOrden_CellClick);
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonAgregar.Location = new System.Drawing.Point(311, 48);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(96, 51);
            this.buttonAgregar.TabIndex = 9;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // buttonModificar
            // 
            this.buttonModificar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonModificar.Location = new System.Drawing.Point(439, 48);
            this.buttonModificar.Name = "buttonModificar";
            this.buttonModificar.Size = new System.Drawing.Size(115, 51);
            this.buttonModificar.TabIndex = 10;
            this.buttonModificar.Text = "Modificar";
            this.buttonModificar.UseVisualStyleBackColor = true;
            this.buttonModificar.Click += new System.EventHandler(this.buttonModificar_Click);
            // 
            // buttonEliminar
            // 
            this.buttonEliminar.Font = new System.Drawing.Font("Segoe UI", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.buttonEliminar.Location = new System.Drawing.Point(581, 48);
            this.buttonEliminar.Name = "buttonEliminar";
            this.buttonEliminar.Size = new System.Drawing.Size(118, 51);
            this.buttonEliminar.TabIndex = 11;
            this.buttonEliminar.Text = "Eliminar";
            this.buttonEliminar.UseVisualStyleBackColor = true;
            this.buttonEliminar.Click += new System.EventHandler(this.buttonEliminar_Click);
            // 
            // DetalleOrdenForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEliminar);
            this.Controls.Add(this.buttonModificar);
            this.Controls.Add(this.buttonAgregar);
            this.Controls.Add(this.dataGridViewDetalleOrden);
            this.Controls.Add(this.comboBoxProducto);
            this.Controls.Add(this.comboBoxOrden);
            this.Controls.Add(this.textBoxCantidad);
            this.Controls.Add(this.labelProducto);
            this.Controls.Add(this.labelOrden);
            this.Controls.Add(this.labelCantidad);
            this.Name = "DetalleOrdenForm";
            this.Text = "Detalle Orden";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDetalleOrden)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Label labelCantidad;
        private Label labelOrden;
        private Label labelProducto;
        private TextBox textBoxCantidad;
        private ComboBox comboBoxOrden;
        private ComboBox comboBoxProducto;
        private DataGridView dataGridViewDetalleOrden;
        private Button buttonAgregar;
        private Button buttonModificar;
        private Button buttonEliminar;
    }
}