﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProyectoSQLServer
{
    public partial class Tarjeta_Cliente : Form
    {
        List<Cliente> clienteList = new List<Cliente>();
        SqlConnection conexion = new SqlConnection("Server=JETERMEDINA\\SQLEXPRESS;" + "Database=ComprasEnLinea;" + "Integrated Security=true;");
        //Variable para la conexion con la base de datos
        int idA = 0; //Variable para id de Cliente para cuando se modificara o eliminara 

        public Tarjeta_Cliente()
        {
            InitializeComponent();
            conectaBD();
            comboBoxCliente.SelectedIndex = -1;
            dateTimePickerFecha.MinDate = new DateTime(2023,6,1);
            dateTimePickerFecha.Value = new DateTime(2024, 1, 1);
            dateTimePickerFecha.Format = DateTimePickerFormat.Custom;
            dateTimePickerFecha.CustomFormat = "MM/yy";
        }

        public int conectaBD()
        {
            try
            {
                conexion.Open(); //Abrimos conexion con la base de datos
                muestra(); //Funcion que muestra en el datagridview las tuplas
                llenalista();
                conexion.Close(); //Cerramos base de datos
                return 0;
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos base de datos
                MessageBox.Show(ex.Message);
                return -1;
            }
        }

        public void muestra()
        {
            string query1 = string.Concat("SELECT T.Id_Cliente, T.Numero_Tarjeta,T.CVV,T.Banco, FORMAT(Fecha,'MM/yy'),CONCAT(C.Nombre_Cliente, ' | ', C.Correo_Electronico) FROM Usuario.Cliente C, " +
                "Datos.Tarjeta_Cliente T WHERE C.Id_Cliente=T.Id_Cliente");

            SqlCommand command = new SqlCommand(query1, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataAdapter adapter = new SqlDataAdapter(command); //Declaramos variable SqlDataAdapter
            DataTable dataTable = new DataTable(); // Declaramos variable de DataTable
            adapter.Fill(dataTable); // Agrega renglones en determinado rango
            dataGridViewTarjetaCliente.DataSource = null;
            //dataTable.Rows.RemoveAt(-1);
            dataGridViewTarjetaCliente.DataSource = dataTable;  //Llenamos el dataGrid con los valores de las tuplas
            dataGridViewTarjetaCliente.Columns[0].HeaderText = "Id Cliente";
            dataGridViewTarjetaCliente.Columns[1].HeaderText = "Número Tarjeta";
            dataGridViewTarjetaCliente.Columns[2].HeaderText = "CVV";
            dataGridViewTarjetaCliente.Columns[3].HeaderText = "Banco";
            dataGridViewTarjetaCliente.Columns[4].HeaderText = "Fecha";
            dataGridViewTarjetaCliente.Columns[5].HeaderText = "Nombre Cliente | Correo Electrónico";
            //dataGridViewTarjetaCliente.Columns[6].HeaderText = "Correo Electrónico";
            limpia(); //Funcion para limpiar los textbox
        }

        public void limpia()
        {
            textBoxNumTarjeta.Clear();
            textBoxCVV.Clear();
            textBoxBanco.Clear();
            dateTimePickerFecha.Value = new DateTime(2024, 1, 1);
            comboBoxCliente.SelectedIndex = -1; //Limpiamos textbox de Correo
        }

        public void llenalista()
        {
            string query = string.Concat("SELECT * FROM Usuario.Cliente"); //Sentencia para mostrar todas la tuplas

            SqlCommand command = new SqlCommand(query, conexion); //Declaramos variable de SqlCommand que lleva la sentencia y la conexion
            SqlDataReader sqlDataReader = command.ExecuteReader();
            while (sqlDataReader.Read())
            {
                Cliente cliente = new Cliente();
                cliente.Id_Cliente = sqlDataReader.GetInt64(0);
                cliente.Nombre_Cliente = sqlDataReader.GetString(1) + " | " + sqlDataReader.GetString(2); 
                //cliente.Correo_Electronico = sqlDataReader.GetString(2);

                clienteList.Add(cliente);
            }
            comboBoxCliente.DataSource = clienteList;
            comboBoxCliente.DisplayMember = "Nombre_Cliente";
            comboBoxCliente.ValueMember = "Id_Cliente";
        }

        private void dataGridViewTarjetaCliente_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            idA = Convert.ToInt32(dataGridViewTarjetaCliente.CurrentRow.Cells[0].Value); //Indicamos el id de la tupla que seleccionamos
            textBoxNumTarjeta.Text = dataGridViewTarjetaCliente.CurrentRow.Cells[1].Value.ToString(); //Llenamoos el textbox de nombre con los datos del datagridview
            textBoxCVV.Text = dataGridViewTarjetaCliente.CurrentRow.Cells[2].Value.ToString();
            textBoxBanco.Text = dataGridViewTarjetaCliente.CurrentRow.Cells[3].Value.ToString();
            dateTimePickerFecha.Value = DateTime.Parse("01/" + dataGridViewTarjetaCliente.CurrentRow.Cells[4].Value.ToString());
            for (int i = 0; i < clienteList.Count; i++)
            {
                if (clienteList[i].Id_Cliente == idA)
                {
                    int id = comboBoxCliente.FindStringExact(clienteList[i].Nombre_Cliente);
                    comboBoxCliente.SelectedIndex = id;
                }
            }
        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            insertaRegistro(); //Mandamos a llamar funcion para insertar tupla
            conectaBD(); //Conectamos a la Base de datos
        }



        public void insertaRegistro()
        {
            try
            {
                conexion.Open();//Abre la conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "INSERT INTO Datos.Tarjeta_Cliente" + "(Id_Cliente, Numero_Tarjeta,CVV,Banco,Fecha) " +
                    "VALUES(" + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + ",'" + textBoxNumTarjeta.Text + "','" + textBoxCVV.Text + "','" +
                    textBoxBanco.Text + "','" + fecha + "')";
                //Sentencia para insertar alumnos con los datos de las textbox
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable SqlDataAdapter
                command.ExecuteNonQuery(); //Ejecutamos el comando
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero Duplicado de Tarjeta"); //Error en la conexion
            }
        }

        private void buttonModificar_Click(object sender, EventArgs e)
        {
            modificaRegistro();//Mandamos a llamar funcion para modificar la tupla
            conectaBD(); //Conectamos a la Base de datos
        }

        public void modificaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string fecha = dateTimePickerFecha.Value.ToString("yyyy-MM-dd");
                string consulta = "UPDATE Datos.Tarjeta_Cliente SET Id_Cliente=" + clienteList[comboBoxCliente.SelectedIndex].Id_Cliente + ",Numero_Tarjeta='"
                    + textBoxNumTarjeta.Text + "',CVV='" + textBoxCVV.Text + "',Banco='" + textBoxBanco.Text + "',Fecha='" + fecha + "' WHERE Id_Cliente=" + idA;
                //Sentencia en SQL para modificar la tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable de tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos la sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiamos los textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cierra conexion
                MessageBox.Show("Error: Numero Duplicado de Tarjeta"); //Error en la conexion
            }
        }

        private void buttonEliminar_Click(object sender, EventArgs e)
        {
            eliminaRegistro(); //Llamamos a la funcion que eliminar la tupla
            conectaBD(); //Conectamos a la Base de Datos
        }

        public void eliminaRegistro()
        {
            try
            {
                conexion.Open(); //Abrimos conexion
                string consulta = "DELETE Datos.Tarjeta_Cliente WHERE Id_Cliente=" + idA + "AND Numero_Tarjeta=" + textBoxNumTarjeta.Text; //Sentencia en SQl para eliminar tupla
                SqlCommand command = new SqlCommand(consulta, conexion); //Declaramos variable tipo SqlCommand
                command.ExecuteNonQuery(); //Ejecutamos sentencia
                conexion.Close(); //Cerramos conexion
                limpia(); //Limpiasmo textbox
            }
            catch (Exception ex)
            {
                conexion.Close(); //Cerramos conexxion
                MessageBox.Show("Error de conexion: " + ex.Message); //Error en la conexion
            }
        }
    }
}
