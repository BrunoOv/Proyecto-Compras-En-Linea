/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuario;

import Datos.Tarjeta_Cliente;
import Datos.Telefono_Cliente;
import Datos.Telefono_Proveedor;
import Menu.Menu;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
/**
 clase de proveedor
 */
public class Proveedor extends javax.swing.JFrame {
    private String HOST="localhost"; //host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public String id;
    public String user;
    /**
     * Creates new form Proveedor
     */
    public Proveedor(String U) {
        initComponents();
        muestra();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(U);
        user=U;
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            Insertar.setEnabled(false);
            Modificar.setEnabled(false);
            Eliminar.setEnabled(false);
        }
    }
    //realiza la conexion con la base de datos a travez del driver
     public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
     // inserta un nuevo proveedor
    public void inserta(){
        //valida que los campos de los datos esten completos
        if(Nombre.getText().equalsIgnoreCase("")||Correo.getText().equalsIgnoreCase("")||Domicilio.getText().equalsIgnoreCase("")){
        JOptionPane.showMessageDialog(this, "Casillas vacias");
        }else{
        try{
          conexion=connectaBD(); // crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para insertar un nuevo proveedor en la tabla Usuario.Proveedor
          String Query="INSERT INTO Usuario.Proveedor(Nombre_Provedoor,Correo_Electronico,Domicilio_Fiscal)"
                  + "VALUES('"+Nombre.getText()+"','"+Correo.getText()+"','"+Domicilio.getText()+"')";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,"Tupla Repetida");
        }
        }
    }
    //obtiene los datos del proveedor
    public void muestra(){
        try{
            conexion=connectaBD(); //crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener a los proveedores y ordenarlos de forma ascendente
            String Query="SELECT * FROM Usuario.Proveedor ORDER BY Id_Proveedor ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            //agrega las columnas al jtable
            model.addColumn("Id Proveedor");
            model.addColumn("Correo Electrónico");
            model.addColumn("Nombre Provedoor");
            model.addColumn("Domicilio Fiscal");
            //llena las columas del jtable
            TProveedor.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4);
                model.addRow(datos);
            }
            // obtiene los datos del proveedor al hacer clic en el renglon dentro del jtable
            TProveedor.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    Nombre.setText(TProveedor.getValueAt(TProveedor.getSelectedRow(),2).toString());
                    Correo.setText(TProveedor.getValueAt(TProveedor.getSelectedRow(),1).toString());
                    Domicilio.setText(TProveedor.getValueAt(TProveedor.getSelectedRow(),3).toString());
                    id=TProveedor.getValueAt(TProveedor.getSelectedRow(), 0).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    //elimina un proveedor
    public void elimina(){
        
        try{
          conexion=connectaBD(); //crea la conexion de la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query para eliminar el telefono del proveedor segun su Id
          String Query="DELETE FROM Datos.Telefono_Proveedor WHERE Id_Proveedor="+id+"";
          // query que elimina al proveedor seleccionado
          String Query2="DELETE FROM Usuario.Proveedor WHERE Id_Proveedor="+id+"";  
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.executeUpdate(Query2);//ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
        
    }
    //acutaliza los datos del proveedor
    public void modifica(){
        try{
          conexion=connectaBD(); // crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // actualiza los datos del proveedor seleccionado
          String Query="UPDATE Usuario.Proveedor SET Nombre_Provedoor='"+Nombre.getText()+"',Correo_Electronico='"+Correo.getText()+"',"
                  + "Domicilio_Fiscal='"+Domicilio.getText()+"'"
                  + "WHERE Id_Proveedor="+id+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);  
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        Insertar = new javax.swing.JButton();
        Modificar = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();
        Telefono = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        TProveedor = new javax.swing.JTable();
        Correo = new javax.swing.JTextField();
        Nombre = new javax.swing.JTextField();
        Domicilio = new javax.swing.JTextField();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Proveedor");

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("Proveedor");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Correo Electrónico");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Nombre");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Domicilio Fiscal");

        Insertar.setText("INSERTAR");
        Insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertarActionPerformed(evt);
            }
        });

        Modificar.setText("MODIFICAR");
        Modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarActionPerformed(evt);
            }
        });

        Eliminar.setText("ELIMINAR");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        Telefono.setText("TELEFONO");
        Telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefonoActionPerformed(evt);
            }
        });

        TProveedor.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane2.setViewportView(TProveedor);

        Correo.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Nombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Domicilio.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane2)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Correo, javax.swing.GroupLayout.DEFAULT_SIZE, 484, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Nombre))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(Domicilio))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(Modificar)
                            .addComponent(Eliminar, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Insertar, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Telefono, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(33, 33, 33))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1)
                        .addGap(12, 12, 12)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Domicilio, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(Insertar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Modificar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Eliminar)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Telefono)))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(33, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void InsertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertarActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Nombre.setText("");
        Correo.setText("");
        Domicilio.setText("");
    }//GEN-LAST:event_InsertarActionPerformed

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        Nombre.setText("");
        Correo.setText("");
        Domicilio.setText("");
    }//GEN-LAST:event_ModificarActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Nombre.setText("");
        Correo.setText("");
        Domicilio.setText("");
    }//GEN-LAST:event_EliminarActionPerformed

    private void TelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefonoActionPerformed
        // TODO add your handling code here:
        Telefono_Proveedor Tp=new Telefono_Proveedor(user);
        Tp.setVisible(true);
        //this.setVisible(false);
    }//GEN-LAST:event_TelefonoActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Correo;
    private javax.swing.JTextField Domicilio;
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton Insertar;
    private javax.swing.JButton Modificar;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTable TProveedor;
    private javax.swing.JButton Telefono;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
