/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuario;

import Datos.Tarjeta_Cliente;
import Datos.Telefono_Cliente;
import Menu.Menu;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.WindowConstants;
import javax.swing.table.DefaultTableModel;

/**
clase para crear un nuevo cliente
 */
public class Cliente extends javax.swing.JFrame {
    private String HOST="localhost"; //host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public String id; // id cliente
    public String user; // usuario
    /**
     * Creates new form Cliente
     */
    public Cliente(String U) {
        initComponents();
        Nombre.setText("");
        Correo.setText("");
        muestra();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(U);
        user=U;
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            insertar.setEnabled(false);
            Modificar.setEnabled(false);
            Eliminar.setEnabled(false);
        }
    }
    //realiza la conexion con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // crea un nuevo cliente
    public void inserta(){
        //valida que los campos esten completos
        if(Nombre.getText().equalsIgnoreCase("")||Correo.getText().equalsIgnoreCase("")){
        JOptionPane.showMessageDialog(this, "Casillas vacias");
        }else{
          try{
          conexion=connectaBD(); //crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para insertar un nuevo cliente en la tabla Usuario.Cliente
          String Query="INSERT INTO Usuario.Cliente(Nombre_Cliente,Correo_Electronico)"
                  + "VALUES('"+Nombre.getText()+"','"+Correo.getText()+"')";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close();//cierra la conexion
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, "Tupla Repetida");
        }
        }
    }
    //muestra los datos del cliente
    public void muestra(){
        try{
            conexion=connectaBD(); //crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query para obtener todos los clientes y ordenarlos de forma ascendente
            String Query="SELECT * FROM Usuario.Cliente ORDER BY Id_Cliente ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            //agrega las columnas al jtable
            model.addColumn("Id Cliente");
            model.addColumn("Nombre Cliente");
            model.addColumn("Correo Electrónico");
            //llena las columnas del jtable
            TCliente.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                model.addRow(datos);
            }
            // selecciona un cliente y obtiene los datos al hacer clic dentro del jtable
            TCliente.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    Nombre.setText(TCliente.getValueAt(TCliente.getSelectedRow(),1).toString());
                    Correo.setText(TCliente.getValueAt(TCliente.getSelectedRow(),2).toString());
                    id=TCliente.getValueAt(TCliente.getSelectedRow(), 0).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    //elimina un cliente
    public void elimina(){
        try{
          conexion=connectaBD(); //crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query para borrar un cliente especifico
          String Query="DELETE FROM Usuario.Cliente WHERE Id_Cliente="+id+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    // acutaliza los datos del cliente
    public void modifica(){
        try{
          conexion=connectaBD(); //crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para actualizar los datos del cliente seleccionado
          String Query="UPDATE Usuario.Cliente SET Nombre_Cliente='"+Nombre.getText()+"',Correo_Electronico='"+Correo.getText()+"'"
                  + "WHERE Id_Cliente="+id+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);  
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        TCliente = new javax.swing.JTable();
        Nombre = new javax.swing.JTextField();
        Correo = new javax.swing.JTextField();
        insertar = new javax.swing.JButton();
        Tarjeta = new javax.swing.JButton();
        Modificar = new javax.swing.JButton();
        Telefono = new javax.swing.JButton();
        Eliminar = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Cliente");

        jLabel1.setFont(new java.awt.Font("Tw Cen MT", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("Cliente");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Correo Electrónico");

        TCliente.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(TCliente);

        Nombre.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        Correo.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        insertar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        insertar.setText("INSERTAR");
        insertar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertarActionPerformed(evt);
            }
        });

        Tarjeta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Tarjeta.setText("TARJETA");
        Tarjeta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TarjetaActionPerformed(evt);
            }
        });

        Modificar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Modificar.setText("MODIFICAR");
        Modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificarActionPerformed(evt);
            }
        });

        Telefono.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Telefono.setText("TELEFONO");
        Telefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TelefonoActionPerformed(evt);
            }
        });

        Eliminar.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Eliminar.setText("ELIMINAR");
        Eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 650, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel2)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 393, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel3)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(Correo)))
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Modificar)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 9, Short.MAX_VALUE)
                                .addComponent(Telefono))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(insertar)
                                        .addGap(18, 18, 18)
                                        .addComponent(Tarjeta))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(Eliminar)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(insertar)
                    .addComponent(Tarjeta))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Modificar)
                    .addComponent(Telefono))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Correo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(Eliminar)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TarjetaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TarjetaActionPerformed
        // TODO add your handling code here:
        Tarjeta_Cliente Tac=new Tarjeta_Cliente(user);
        Tac.setVisible(true);
        //this.setVisible(false);
    }//GEN-LAST:event_TarjetaActionPerformed

    private void TelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TelefonoActionPerformed
        // TODO add your handling code here:
        Telefono_Cliente Tc=new Telefono_Cliente(user);
        Tc.setVisible(true);
        //this.setVisible(false);
    }//GEN-LAST:event_TelefonoActionPerformed

    private void insertarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertarActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Nombre.setText("");
        Correo.setText("");
    }//GEN-LAST:event_insertarActionPerformed

    private void ModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificarActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        Nombre.setText("");
        Correo.setText("");
    }//GEN-LAST:event_ModificarActionPerformed

    private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminarActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Nombre.setText("");
        Correo.setText("");
    }//GEN-LAST:event_EliminarActionPerformed

    /**
     * @param args the command line arguments
     */

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Correo;
    private javax.swing.JButton Eliminar;
    private javax.swing.JButton Modificar;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTable TCliente;
    private javax.swing.JButton Tarjeta;
    private javax.swing.JButton Telefono;
    private javax.swing.JButton insertar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
