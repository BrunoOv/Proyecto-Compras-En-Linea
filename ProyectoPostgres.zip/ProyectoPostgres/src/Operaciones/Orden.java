/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;
import Usuario.Cliente;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import Menu.Menu;
import java.util.Calendar;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;

/*
vista donde se muestran las ordenes creadas
*/
public class Orden extends javax.swing.JFrame {
    private String HOST="localhost"; //host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public String id; // id de la orden
    public String numeros; // numero de la orden
    public LinkedList<String> ids=new LinkedList<>();
    public LinkedList<String> fechas=new LinkedList<>();
    public LinkedList<String> correos=new LinkedList<>();
    public String user; // usuario
    /**
     * Creates new form Orden
     */
    public Orden(String U) {
        initComponents();
        proveedor();
        muestra();
        fecha();
        usuario(U);
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        user=U;
    }
     public void usuario(String u){
        if(u.equals("pablo")){
            inserta.setEnabled(false);
            modifica.setEnabled(false);
            elimina.setEnabled(false);
        }
    }
     // da formato y muestra el calendario en la vista
    public void fecha(){
        Calendar fechaActual = Calendar.getInstance();
        fecha.setSelectableDateRange(fechaActual.getTime(),null);           
    }
    // obtiene los proveedores
    public void proveedor(){
        try{
            conexion=connectaBD(); // crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // obitene los datos de los proveedores
            String Query="SELECT Nombre_Provedoor,Id_Proveedor,Correo_Electronico FROM Usuario.Proveedor ORDER BY Id_Proveedor ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            //llena los campos con la informacion del proveedor
            while(columnas.next()){
               provedores.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               ids.addLast(columnas.getString(2));
              
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    //conecta con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // muestra las ordenes
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // muestra los datos de la orden y del proveedor
            String Query="SELECT D.Num_Orden,D.Fecha_Orden,D.Total,P.Nombre_Provedoor,P.Correo_Electronico FROM Operaciones.Orden D,Usuario.Proveedor P WHERE D.Id_Proveedor=P.Id_Proveedor ORDER BY D.Num_Orden ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
          // crea las columnas del jtable
            model.addColumn("Número De Orden");
            model.addColumn("Fecha De Orden");
            model.addColumn("Total");
            model.addColumn("Nombre Proveedor - Correo Electrónico");
            //llena las columnas con los datos de la orden
            Ordenes.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4)+" - "+columnas.getString(5);
                correos.add(columnas.getString(5));
                model.addRow(datos);
            }
            // obtiene los datos del renglón al hacer clic dentro del jtable
            Ordenes.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    // busqueda de los correos
                    id=busqueda(correos.get(Ordenes.getSelectedRow()));
                    for (int i =0; i < ids.size(); i++){
                    if(ids.get(i).equals(id)){
                        provedores.setSelectedIndex(i);
                    }
                    }               
                    // id de las ordenes
                    id=Ordenes.getValueAt(Ordenes.getSelectedRow(), 0).toString();
                    total.setText(Ordenes.getValueAt(Ordenes.getSelectedRow(), 2).toString());
                    try{
                    conexion=connectaBD(); // crea una conexion con la base de datos
                    java.sql.Statement corrida;
                    // obitene la fecha de la creacion de la orden
                    String Query="SELECT to_char(Fecha_Orden,'yyyy/MM/dd') FROM Operaciones.Orden WHERE Num_Orden='"+id+"'";
       
                    corrida=conexion.createStatement();
                    ResultSet columnas=corrida.executeQuery(Query); //ejeucta el query  
                    while(columnas.next()){
                    ((JTextField)fecha.getDateEditor().getUiComponent()).setText(columnas.getString(1));
                    }
                    corrida.close();
                    conexion.close(); //cierra la conexion
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex); 
                    }
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    // busca el proveedor segun el correo que recibe como parametro
    public String busqueda(String cadena){
        String Query1="";
        try{
           conexion=connectaBD(); // conexion a la base de datos
           java.sql.Statement corrida;
           // obitene el proveedor relacionado al correo
           Query1="SELECT Id_Proveedor FROM Usuario.Proveedor WHERE Correo_Electronico='"+cadena+"'";
           corrida=conexion.createStatement();
           ResultSet columnas=corrida.executeQuery(Query1);  //ejecuta el query
             while(columnas.next()){
                Query1=columnas.getString(1);
               }
          corrida.close();
          conexion.close(); //cierra la conexion
      }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex); 
    }
      return Query1;  
    }
         // inserta una nueva orden
    public void inserta(){
          try{
          conexion=connectaBD();// crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          Pattern patron = Pattern.compile("\\d+");
          Matcher matcher = patron.matcher(total.getText());
          String num="";
          while (matcher.find()) {
            num = matcher.group();
            }
          //inserta nueva orden en la tabla Operaciones.Orden
          String Query="INSERT INTO Operaciones.Orden(Id_Proveedor,Fecha_Orden,Total)"
                  + "VALUES('"+ids.get(provedores.getSelectedIndex())+"','"+(((JTextField)fecha.getDateEditor().getUiComponent()).getText())+"',"+num+")";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
        }
    }
    //elimina una orden
    public void elimina(){
        try{
          conexion=connectaBD();// crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query que elimina una orden seleccionada
          String Query="DELETE FROM Operaciones.Orden WHERE Num_Orden="+Ordenes.getValueAt(Ordenes.getSelectedRow(), 0).toString()+" ";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close();  //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    //modifica la tupla en la base de datos
    public void modifica(){
        try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query que actualiza la orden con los nuevos datos de los textfield 
            String Query="UPDATE Operaciones.Orden SET "
                  + "Id_Proveedor= "+ids.get(provedores.getSelectedIndex())+" , Fecha_Orden='"+(((JTextField)fecha.getDateEditor().getUiComponent()).getText())+"', Total= '"+Ordenes.getValueAt(Ordenes.getSelectedRow(), 2).toString()+"' "
                    + "WHERE Num_Orden="+Ordenes.getValueAt(Ordenes.getSelectedRow(), 0).toString()+"";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();// cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        inserta = new javax.swing.JButton();
        elimina = new javax.swing.JButton();
        modifica = new javax.swing.JButton();
        Detalle = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        fecha = new com.toedter.calendar.JDateChooser();
        total = new javax.swing.JLabel();
        provedores = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        Ordenes = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Orden");

        inserta.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        inserta.setText("INSERTA");
        inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertaActionPerformed(evt);
            }
        });

        elimina.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        elimina.setText("ELIMINA");
        elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminaActionPerformed(evt);
            }
        });

        modifica.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        modifica.setText("MODIFICA");
        modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificaActionPerformed(evt);
            }
        });

        Detalle.setFont(new java.awt.Font("sansserif", 2, 14)); // NOI18N
        Detalle.setForeground(new java.awt.Color(255, 102, 0));
        Detalle.setText("DETALLE ORDEN");
        Detalle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DetalleActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("sansserif", 3, 14)); // NOI18N
        jLabel1.setText("Orden");

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("Fecha De Orden");

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Total");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setText("Proveedor");

        total.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        total.setForeground(new java.awt.Color(255, 0, 0));
        total.setText("$0.00");

        Ordenes.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Ordenes);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 996, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(17, 17, 17)
                                .addComponent(total))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(provedores, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(inserta, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(modifica)
                                .addGap(18, 18, 18)
                                .addComponent(Detalle, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(elimina, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(inserta)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(elimina)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(modifica)
                            .addComponent(Detalle)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(total, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(provedores, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 315, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(38, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertaActionPerformed
        // TODO add your handling code here:
        inserta();
        correos.clear();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_insertaActionPerformed

    private void DetalleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DetalleActionPerformed
        // TODO add your handling code here:
        Detalle_Orden d=new Detalle_Orden(user);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_DetalleActionPerformed

    private void eliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminaActionPerformed
        // TODO add your handling code here:
        elimina();
        correos.clear();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_eliminaActionPerformed

    private void modificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificaActionPerformed
        // TODO add your handling code here:
        modifica();
        correos.clear();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_modificaActionPerformed

   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Detalle;
    private javax.swing.JTable Ordenes;
    private javax.swing.JButton elimina;
    private com.toedter.calendar.JDateChooser fecha;
    private javax.swing.JButton inserta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modifica;
    private javax.swing.JComboBox provedores;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
