/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
vista donde se muestran las devoluciones de cada carrito y los productos a devolver
*/
public class Devolucion_Carrito extends javax.swing.JFrame {
    private String HOST="localhost";//host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public LinkedList<String> idsProductos=new LinkedList<>();
    public LinkedList<String> idsCarritos=new LinkedList<>();
    public String user;// usuario
    /**
     * Creates new form Devolucion_Carrito
     */
    public Devolucion_Carrito(String U) {
        initComponents();
        muestra();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cierra();
        fecha();
        carritos();
        productos();
        usuario(U);
        user=U;
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            INSERTA.setEnabled(false);
            MODIFICA.setEnabled(false);
            ELIMINA.setEnabled(false);
        }
    }
    // da formato a la fecha
  public void fecha() {
    Calendar fechaActual = Calendar.getInstance();

    // Formatear la fecha actual a un formato de String
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    String fechaFormateada = formatoFecha.format(fechaActual.getTime());

    fecha.setText(fechaFormateada);
}
  // conexión con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // cierra la vista
    public void cierra(){
         this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
              Carrito_Venta d=new Carrito_Venta(user);
              d.setVisible(true);
            }
        });
    }
    //obtiene los carritos de la base de datos
    public void carritos(){
        try{
            conexion=connectaBD();// crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query que obtiene el nombre del cliente y el carrito relacionado al cliente
            String Query="SELECT C.Nombre_Cliente,O.Id_Carrito \n" +
            "FROM Operaciones.Carrito_Venta O,Usuario.Cliente C,Datos.Tarjeta_Cliente T \n" +
            "WHERE C.Id_Cliente=T.Id_Cliente AND T.Id_Tarjeta=O.Id_Tarjeta_Cliente AND O.Total_Carrito> '0'::money\n" +
            "ORDER BY O.Id_Carrito ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            while(columnas.next()){
               Carritos.addItem(columnas.getString(2)+" "+columnas.getString(1));
               idsCarritos.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
            //obtiene los productos de la base de datos
    public void productos(){
        Carritos.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try{
            conexion=connectaBD();// crea la coenxion a la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            Productos.removeAllItems();
            // obtiene los productos relacionados al carrito
            String Query="SELECT P.Nombre_Producto,P.Id_Producto,P.Precio_Publico_Producto FROM Articulo.Producto P,Operaciones.Detalle_Carrito D"
                    + " WHERE D.Id_Carrito="+idsCarritos.get(Carritos.getSelectedIndex())+" AND "
                    + "P.Id_Producto=D.Id_Producto AND D.Cantidad>0 ORDER BY P.Id_Producto ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            while(columnas.next()){
               Productos.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               idsProductos.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
             
               }
        });
        
    }
    //muestra segun el carrito los productos a devolver
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la conexión a la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query que obtiene el carrito y los datos del prodcuto relacionado al carrito 
            String Query="SELECT O.Id_Carrito,O.Cantidad_Producto,O.Fecha,P.Nombre_Producto,P.Precio_Publico_Producto\n" +
            "FROM Operaciones.Devolucion_Carrito O,Articulo.Producto P\n" +
            "WHERE O.Id_Producto=P.Id_Producto";
            String[]datos =new String[7];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            //agrega las columnas al jtable
            model.addColumn("Id Carrito");
            model.addColumn("Cantidad");
            model.addColumn("Fecha");
            model.addColumn("Nombre Producto - Precio Público Producto");
            // ingresa los datos al jtable
            Devoluciones.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4)+" - "+columnas.getString(5);
                model.addRow(datos);
            }
            // obtiene los datos del renglón al hacer clic dentro del jtable
            Devoluciones.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){ 
                   for (int i =0; i < idsCarritos.size(); i++){
                    if(idsCarritos.get(i).equals((Devoluciones.getValueAt(Devoluciones.getSelectedRow(),0).toString()))){
                    Carritos.setSelectedIndex(i);
                    }
                    }
                   String valor = Devoluciones.getValueAt(Devoluciones.getSelectedRow(), 3).toString();
                   String id = buscaProducto(valor);
                   for (int i =0; i < idsProductos.size(); i++){
                    if(idsProductos.get(i).equals(id)){
                    Productos.setSelectedIndex(i);
                    }
                    }
                   
                   try{
                    conexion=connectaBD(); // inicia conexion de la base de datos
                    java.sql.Statement corrida;
                    // obtiene la fecha de la devolucion segun el carrito
                    String Query="SELECT to_char(Fecha,'yyyy/MM/dd') FROM Operaciones.Devolucion_Carrito WHERE Id_Carrito="+((Devoluciones.getValueAt(Devoluciones.getSelectedRow(),0).toString()))+"";
       
                    corrida=conexion.createStatement();
                    ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query  
                    while(columnas.next()){
                     fecha.setText(columnas.getString(1));
                    }
                    corrida.close();
                    conexion.close(); // cierra la conexion
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex); 
                    }
                   Cantidad.setText(((Devoluciones.getValueAt(Devoluciones.getSelectedRow(),1).toString())));
                 
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    // busca el producto en la base de datos, recibiendo el nombre como parametro
    public String buscaProducto(String cadena){
        String Query1="";//variable para el query
        try{
           conexion=connectaBD(); //crea la conexion con la base de datos
           java.sql.Statement corrida;
           //query para obtener el producto con el nombre rebicido
           Query1="SELECT Id_Producto FROM Articulo.Producto WHERE Nombre_Producto='"+cadena+"'";
           corrida=conexion.createStatement();
           ResultSet columnas=corrida.executeQuery(Query1);  //ejecuta el query
             while(columnas.next()){
                Query1=columnas.getString(1);
               }
          corrida.close();
          conexion.close(); //cierra la conexion
      }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex); 
    }
      return Query1;  
    }
    // modifica la devolucion
     public void modifica(){
          try{
          conexion=connectaBD();//crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // nuevos datos para la modificación
          String i=Devoluciones.getValueAt(Devoluciones.getSelectedRow(), 0).toString();
          String Ca=Devoluciones.getValueAt(Devoluciones.getSelectedRow(),1).toString();
          String valor = Devoluciones.getValueAt(Devoluciones.getSelectedRow(), 3).toString();   
          String idProducto = buscaProducto(valor);
          String FechaBusca = Devoluciones.getValueAt(Devoluciones.getSelectedRow(),2).toString();
          //query para actualizar la tupla de la tabla Operaciones.Devolucion_Carrito
          String Query="UPDATE Operaciones.Devolucion_Carrito SET "
                  + "Id_Carrito="+idsCarritos.get(Carritos.getSelectedIndex())+",Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+",Cantidad_Producto="+Cantidad.getText()+",fecha='"+ fecha.getText()+"' "
                  + " WHERE Id_Carrito="+i+" AND Cantidad_Producto="+Ca+" AND Id_Producto="+idProducto+" AND Fecha='"+FechaBusca+"'";
          corrida.executeUpdate(Query);//ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,ex);
        }
     }
     // inserta una nueva devolución
     public void inserta(){
         try{
          conexion=connectaBD(); // crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para crear una nueva devolucion en la tabla Operaciones.Devolucion_Carrito
          String Query="INSERT INTO Operaciones.Devolucion_Carrito(Id_Carrito,Fecha,Id_Producto,Cantidad_Producto) "
                  + "VALUES("+idsCarritos.get(Carritos.getSelectedIndex())+",'"+fecha.getText()+"',"+idsProductos.get(Productos.getSelectedIndex())+","+Cantidad.getText()+")";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cirerra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,"No tienes tantos productos");
        }
     }
     //elimina una devolucion
     public void elimina(){
         try{
          conexion=connectaBD(); // conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // elimina de la tabla Operaciones.Devolucion_Carrito, la devolucion seleccionada
          String Query="DELETE FROM Operaciones.Devolucion_Carrito WHERE Id_Carrito="+idsCarritos.get(Carritos.getSelectedIndex())+" AND "
                  + "Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+" "
                  + "AND Cantidad_Producto="+Cantidad.getText()+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
     }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Carritos = new javax.swing.JComboBox();
        Productos = new javax.swing.JComboBox();
        Cantidad = new javax.swing.JTextField();
        MODIFICA = new javax.swing.JButton();
        ELIMINA = new javax.swing.JButton();
        INSERTA = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Devoluciones = new javax.swing.JTable();
        fecha = new javax.swing.JLabel();

        jLabel5.setText("jLabel5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Devolución Carrito");

        jLabel1.setFont(new java.awt.Font("sansserif", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 51, 255));
        jLabel1.setText("Devolución Carrito");

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("Carrito");

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Producto");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setText("Cantidad");

        jLabel6.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel6.setText("Fecha");

        Carritos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarritosActionPerformed(evt);
            }
        });

        MODIFICA.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        MODIFICA.setText("MODIFICA");
        MODIFICA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MODIFICAActionPerformed(evt);
            }
        });

        ELIMINA.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        ELIMINA.setText("ELIMINA");
        ELIMINA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ELIMINAActionPerformed(evt);
            }
        });

        INSERTA.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        INSERTA.setText("INSERTA");
        INSERTA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INSERTAActionPerformed(evt);
            }
        });

        Devoluciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Devoluciones);

        fecha.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        fecha.setText("Fecha");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Productos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel2))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addComponent(fecha))
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(25, 25, 25)
                                        .addComponent(Carritos, javax.swing.GroupLayout.PREFERRED_SIZE, 202, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGap(24, 24, 24)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(INSERTA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(MODIFICA, javax.swing.GroupLayout.DEFAULT_SIZE, 119, Short.MAX_VALUE)
                            .addComponent(ELIMINA, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                .addGap(0, 414, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 845, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Carritos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Productos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(MODIFICA))
                        .addGap(8, 8, 8)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(ELIMINA))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(fecha)))
                    .addComponent(INSERTA))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 309, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void INSERTAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INSERTAActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Productos.removeAllItems();
    }//GEN-LAST:event_INSERTAActionPerformed

    private void MODIFICAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MODIFICAActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        Productos.removeAllItems();
        
    }//GEN-LAST:event_MODIFICAActionPerformed

    private void ELIMINAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ELIMINAActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Productos.removeAllItems();
    }//GEN-LAST:event_ELIMINAActionPerformed

    private void CarritosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarritosActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_CarritosActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cantidad;
    private javax.swing.JComboBox Carritos;
    private javax.swing.JTable Devoluciones;
    private javax.swing.JButton ELIMINA;
    private javax.swing.JButton INSERTA;
    private javax.swing.JButton MODIFICA;
    private javax.swing.JComboBox Productos;
    private javax.swing.JLabel fecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
