/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *vista donde puedes ver las ventas del carrito, agregar, modificar o eliminar.
 */
public class Carrito_Venta extends javax.swing.JFrame {
    private String HOST="localhost"; //host
    private String PUERTO="5432"; //puerto
    private String DB="ComprasEnLinea"; //base de datos
    private String USER="postgres"; //usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null; // variable para la base de datos
    public LinkedList<String> ids=new LinkedList<>();
    public String user; // usuario
    /**
     * Creates new form Carrito_Venta
     */
    public Carrito_Venta(String U) {
        initComponents();
        muestra();
        fecha();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        clientes();
        usuario(U);
        user=U;
    }
     public void usuario(String u){
        if(u.equals("pablo")){
            INSERTAR.setEnabled(false);
            MODIFICAR.setEnabled(false);
            ELIMINAR.setEnabled(false);
        }
    }
    
/   // muestra los clientes que esten realizando compras
    public void clientes(){
        try{
            conexion=connectaBD(); //crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query que obtiene todos los clientes que esten realizando compras, junto con su forma de pago
            String Query="SELECT U.Nombre_Cliente,T.Id_Tarjeta,Correo_Electronico FROM Usuario.Cliente U,Datos.Tarjeta_Cliente T WHERE U.Id_Cliente=T.Id_Cliente ORDER BY U.Id_Cliente ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            //agrega la informacion al jtable
            while(columnas.next()){
               Clientes.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               ids.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    //conecta con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    
    //da formato a la fecha
    public void fecha() {
    Calendar fechaActual = Calendar.getInstance();
    // Formatear la fecha actual a un formato de String
    SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
    String fechaFormateada = formatoFecha.format(fechaActual.getTime());
    fecha.setText(fechaFormateada);
}
    // muestra todas las compras en el jtable
    public void muestra(){
        try{
            conexion=connectaBD(); //crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para mostrar las compras junto con el nombre del client, la forma de pago y fecha de la compra
            String Query="SELECT C.Id_Carrito,Cl.Nombre_Cliente,C.Forma_De_Pago,to_char(Fecha_Venta,'yyyy/MM/dd'),C.Total_Carrito,T.Banco,RIGHT(T.Numero_Tarjeta,4),Cl.Id_Cliente,Cl.Correo_Electronico\n" +
"           FROM Operaciones.Carrito_Venta C,Usuario.Cliente Cl,Datos.Tarjeta_Cliente T\n" +
"           WHERE C.Id_Tarjeta_Cliente=T.Id_Tarjeta AND T.Id_Cliente=Cl.Id_Cliente\n" +
"           ORDER BY C.Id_Carrito\n" +
"           ";
            String[]datos =new String[7];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            // crea las columnas para almacenar la información
            model.addColumn("Id Carrito");
            model.addColumn("Nombre Cliente - Correo Electrónico");
            model.addColumn("Forma De Pago");
            model.addColumn("Fecha Venta");
            model.addColumn("Total");
            model.addColumn("Banco");
            model.addColumn("Número Tarjeta");
            // llena las columnas con los datos obtenidos
            carritos.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2)+" - "+columnas.getString(9);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4);
                datos[4]=columnas.getString(5);
                datos[5]=columnas.getString(6);
                datos[6]=columnas.getString(7);
           
                model.addRow(datos);
            }
            
            int columnWidth = 150; // Tamaño de columna en píxeles
            int columnIndex = 1; // Índice de la columna a modificar
            carritos.getColumnModel().getColumn(columnIndex).setPreferredWidth(columnWidth);
            // obitene los datos de la compra al hacer clic en el renglon del jtable
            carritos.addMouseListener(new MouseAdapter() {
                //al hacer clic dentro del jtable, obtiene los datos del rengón
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point); // numero del renglon
                if(Mouse_evt.getClickCount()==1){
                    String valor = carritos.getValueAt(carritos.getSelectedRow(), 6).toString();
                    String id = busqueda(valor);
                    for (int i =0; i < ids.size(); i++){
                    if(ids.get(i).equals(id)){
                        Clientes.setSelectedIndex(i);
                    }
                    }
                     // obtiene los datos segun el id
                    id=carritos.getValueAt(carritos.getSelectedRow(), 0).toString();
                    total.setText(carritos.getValueAt(carritos.getSelectedRow(), 4).toString());
                    if(carritos.getValueAt(carritos.getSelectedRow(), 2).toString().equals("Debito")){
                        Pago.setSelectedIndex(0);
                    }else{
                        Pago.setSelectedIndex(1);
                    }
                    try{
                    conexion=connectaBD(); // hace la conexion con la base de datos
                    java.sql.Statement corrida;
                    //query que obtiene la fecha convertida en char 
                    String Query="SELECT to_char(Fecha_Venta,'yyyy/MM/dd') FROM Operaciones.Carrito_Venta WHERE Id_Carrito="+id+"";
                    corrida=conexion.createStatement();
                    ResultSet columnas=corrida.executeQuery(Query);  
                    while(columnas.next()){
                    fecha.setText(columnas.getString(1));
                    }
                    corrida.close();
                    conexion.close();
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex); 
                    }
                 
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    //obitene la compra segun la tarjeta
    public String busqueda(String cadena){
        String Query1="";
        try{
           conexion=connectaBD(); // crea la conexion con la base de datos
           java.sql.Statement corrida;
           // query que obtiene todas las compras realizadas con el numero de tarjeta
           Query1="SELECT Id_Tarjeta FROM Datos.Tarjeta_Cliente WHERE RIGHT(Numero_Tarjeta,4)='"+cadena+"'";
           corrida=conexion.createStatement();
           ResultSet columnas=corrida.executeQuery(Query1); // ejecuta el query
             while(columnas.next()){
                Query1=columnas.getString(1);
               }
          corrida.close();
          conexion.close();// cierra la conexion con la base de datos
      }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex); 
    }
      return Query1;  
    }
    
    // inserta una nueva compra/venta
    public void inserta(){
        try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para insertar una nueva venta en la base de datos
          String Query="INSERT INTO Operaciones.Carrito_Venta(Id_Tarjeta_Cliente,Forma_De_Pago,Fecha_Venta,Total_Carrito)"
                  + "VALUES('"+ids.get(Clientes.getSelectedIndex())+"','"+Pago.getSelectedItem()+"','"+fecha.getText()+"','"+total.getText()+"')";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    // elimina una venta del carrito
    public void elimina(){
        try{
          conexion=connectaBD(); // crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para eliminar una venta del carrito
          String Query="DELETE FROM Operaciones.Carrito_Venta WHERE Id_Carrito="+carritos.getValueAt(carritos.getSelectedRow(), 0).toString()+" ";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, "No se puede eliminar porque tiene productos en el");
        }
    }
    
    // modfica la venta del carrito
    public void modifica(){
        try{
          conexion=connectaBD(); //crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          Pattern patron = Pattern.compile("\\d+");
          Matcher matcher = patron.matcher(carritos.getValueAt(carritos.getSelectedRow(), 0).toString());
          String num="";
          while (matcher.find()) {
            num = matcher.group();
            }
          //query para actualizar la venta del carito
            String Query="UPDATE Operaciones.Carrito_Venta SET "
                  + "Id_Tarjeta_Cliente= "+ids.get(Clientes.getSelectedIndex())+" , Fecha_Venta='"+fecha.getText()+"', Total_Carrito= '"+carritos.getValueAt(carritos.getSelectedRow(), 4).toString()+"' "
                    + "WHERE Id_Carrito="+num+"";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();// cierra la conexion
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        INSERTAR = new javax.swing.JButton();
        MODIFICAR = new javax.swing.JButton();
        DEVOLUCION = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        ELIMINAR = new javax.swing.JButton();
        DETALLE = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        carritos = new javax.swing.JTable();
        Clientes = new javax.swing.JComboBox();
        Pago = new javax.swing.JComboBox();
        total = new javax.swing.JLabel();
        fecha = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Carrito Venta");

        INSERTAR.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        INSERTAR.setText("INSERTAR");
        INSERTAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INSERTARActionPerformed(evt);
            }
        });

        MODIFICAR.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        MODIFICAR.setText("MODIFICAR");
        MODIFICAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MODIFICARActionPerformed(evt);
            }
        });

        DEVOLUCION.setBackground(new java.awt.Color(0, 0, 0));
        DEVOLUCION.setForeground(new java.awt.Color(0, 255, 255));
        DEVOLUCION.setText("DEVOLUCIÓN");
        DEVOLUCION.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DEVOLUCIONActionPerformed(evt);
            }
        });

        jLabel1.setForeground(new java.awt.Color(255, 0, 51));
        jLabel1.setText("Carrito Venta");

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("Cliente");

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Forma De Pago");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setText("Fecha");

        jLabel5.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel5.setText("Total");

        ELIMINAR.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        ELIMINAR.setText("ELIMINAR");
        ELIMINAR.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ELIMINARActionPerformed(evt);
            }
        });

        DETALLE.setBackground(new java.awt.Color(0, 0, 0));
        DETALLE.setForeground(new java.awt.Color(0, 255, 255));
        DETALLE.setText("DETALLE CARRITO");
        DETALLE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DETALLEActionPerformed(evt);
            }
        });

        carritos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(carritos);

        Clientes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClientesActionPerformed(evt);
            }
        });

        Pago.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Debito", "Credito" }));

        total.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        total.setForeground(new java.awt.Color(255, 51, 51));
        total.setText("$0.00");

        fecha.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        fecha.setText("fecha/Hola");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(total))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(fecha))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(Pago, javax.swing.GroupLayout.PREFERRED_SIZE, 221, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, 132, Short.MAX_VALUE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(Clientes, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(107, 107, 107)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(INSERTAR, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(MODIFICAR)
                        .addComponent(ELIMINAR, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(84, 84, 84)
                .addComponent(DEVOLUCION, javax.swing.GroupLayout.PREFERRED_SIZE, 137, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(DETALLE)
                .addGap(245, 245, 245))
            .addComponent(jScrollPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(INSERTAR)
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(MODIFICAR)
                            .addComponent(DEVOLUCION, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(DETALLE, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(ELIMINAR))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Clientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Pago, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(fecha)
                            .addComponent(jLabel4))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(jLabel5))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addComponent(total)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 282, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(14, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ClientesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClientesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ClientesActionPerformed

    private void DETALLEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DETALLEActionPerformed
        // TODO add your handling code here:
        Detalle_Carrito d=new Detalle_Carrito(user);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_DETALLEActionPerformed

    private void DEVOLUCIONActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DEVOLUCIONActionPerformed
        // TODO add your handling code here:
        Devolucion_Carrito d=new Devolucion_Carrito(user);
        d.setVisible(true);
        this.setVisible(false);
    }//GEN-LAST:event_DEVOLUCIONActionPerformed

    private void INSERTARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INSERTARActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_INSERTARActionPerformed

    private void ELIMINARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ELIMINARActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_ELIMINARActionPerformed

    private void MODIFICARActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MODIFICARActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        total.setText("$0.00");
    }//GEN-LAST:event_MODIFICARActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Clientes;
    private javax.swing.JButton DETALLE;
    private javax.swing.JButton DEVOLUCION;
    private javax.swing.JButton ELIMINAR;
    private javax.swing.JButton INSERTAR;
    private javax.swing.JButton MODIFICAR;
    private javax.swing.JComboBox Pago;
    private javax.swing.JTable carritos;
    private javax.swing.JLabel fecha;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel total;
    // End of variables declaration//GEN-END:variables
}
