/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 vista donde se muestran los detalles del carrito
 */
public class Detalle_Carrito extends javax.swing.JFrame {
    private String HOST="localhost";//host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public LinkedList<String> idsProductos=new LinkedList<>();
    public LinkedList<String> idsCarritos=new LinkedList<>();
    public String user;// usuario
    /**
     * Creates new form Detalle_Carrito
     */
    public Detalle_Carrito(String U) {
        initComponents();
        muestra();
        productos();
        carritos();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        cierra();
        usuario(U);
        user=U;
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            INSERTA.setEnabled(false);
            MODIFICA.setEnabled(false);
            ELIMINA.setEnabled(false);
        }
    }
    //conecta con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // cierra la vista
    public void cierra(){
         this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
              Carrito_Venta d=new Carrito_Venta(user);
              d.setVisible(true);
            }
        });
    }
    // muestra los carritos en el jtable
    public void carritos(){
        try{
            conexion=connectaBD(); // crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener todos los carritos de la base de datos de forma ascendente seún su Id
            String Query="SELECT C.Nombre_Cliente,O.Id_Carrito \n" +
            "FROM Operaciones.Carrito_Venta O,Usuario.Cliente C,Datos.Tarjeta_Cliente T \n" +
            "WHERE C.Id_Cliente=T.Id_Cliente AND T.Id_Tarjeta=O.Id_Tarjeta_Cliente \n" +
            "ORDER BY O.Id_Carrito ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            while(columnas.next()){
               Carritos.addItem(columnas.getString(2)+" - "+columnas.getString(1));
               idsCarritos.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    //obtiene los productos de la base de datos
    public void productos(){
        try{
            conexion=connectaBD(); // crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query para obtener los productos de la base de datos
            String Query="SELECT Nombre_Producto,Id_Producto,Precio_Publico_Producto FROM Articulo.Producto ORDER BY Id_Producto ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecutar el query
            while(columnas.next()){
               Productos.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               idsProductos.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    // inserta un nuevo detalle carrito
    public void inserta(){
         try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para insertar un nuevo detalle carrito
          String Query="INSERT INTO Operaciones.Detalle_Carrito(Id_Carrito,Id_Producto,Cantidad,SubTotal)"
                  + "VALUES("+idsCarritos.get(Carritos.getSelectedIndex())+","+idsProductos.get(Productos.getSelectedIndex())+","+Cantidad.getText()+",NULL)";
          corrida.executeUpdate(Query); // ejecutar el query
          corrida.close();
          conexion.close(); // cierra la conexión
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,"Sobrepasa los productos en existencia");
        }
     }
    
        // muestra todos los detalles carrito en el jtable
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener el detalle de cada carrito, concatena el id del carrito, los datos del cliente con su forma de pago y los detalles del producto
            String Query="SELECT CONCAT(C.Id_Carrito,' - ',Cl.Nombre_Cliente),D.Cantidad,D.SubTotal,P.Nombre_Producto,P.Precio_Publico_Producto \n" +
            "FROM Operaciones.Detalle_Carrito D,Operaciones.Carrito_Venta C,Usuario.Cliente Cl,Datos.Tarjeta_Cliente T,Articulo.Producto P\n" +
            "WHERE C.Id_Carrito=D.Id_Carrito AND C.Id_Tarjeta_Cliente=T.Id_Tarjeta AND T.Id_Cliente=Cl.Id_Cliente AND P.Id_Producto=D.Id_Producto\n" +
            "ORDER BY D.Id_Carrito ASC";
            String[]datos =new String[7];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            //agrega las columnas en el jtable
            model.addColumn("Carrito Cliente");
            model.addColumn("Cantidad");
            model.addColumn("SubTotal");
            model.addColumn("Nombre Producto - Precio Público Producto");
            // inserta la informacion en el jtable
            Detalles.setModel(model);
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4)+" - "+columnas.getString(5);
             
           
                model.addRow(datos);
            }
            // obtiene los datos del renglón al hacer clic dentro del jtable
            Detalles.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    // llena los jtextfield de cantidad y subtotal
                   Cantidad.setText(Detalles.getValueAt(Detalles.getSelectedRow(),1).toString());
                   subtotal.setText(Detalles.getValueAt(Detalles.getSelectedRow(),2).toString());
                   String valor = Detalles.getValueAt(Detalles.getSelectedRow(), 3).toString();
                   String id = buscaProducto(valor);
                    for (int i =0; i < idsProductos.size(); i++){
                    if(idsProductos.get(i).equals(id)){
                    Productos.setSelectedIndex(i);
                    }
                    }
                    String valor2 = Detalles.getValueAt(Detalles.getSelectedRow(), 0).toString();
                    Pattern patron = Pattern.compile("\\d+");
                    Matcher matcher = patron.matcher(valor2);
                    String num="";
                    while (matcher.find()) {
                     num = matcher.group();
                    }
                    for (int i =0; i < idsCarritos.size(); i++){
                    if(idsCarritos.get(i).equals(num)){
                    Carritos.setSelectedIndex(i);
                    }
                    }
                 
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    // método que obtiene un producto de la tabla Articulo.Producto
    public String buscaProducto(String cadena){
        String Query1=""; // variable para el query
        try{
           conexion=connectaBD(); // conexion de la base de datos
           java.sql.Statement corrida;
           // query que obtiene los datos del producto segun su nombre
           Query1="SELECT Id_Producto FROM Articulo.Producto WHERE Nombre_Producto='"+cadena+"'";
           corrida=conexion.createStatement();
           ResultSet columnas=corrida.executeQuery(Query1);  
             while(columnas.next()){
                Query1=columnas.getString(1);
               }
          corrida.close();
          conexion.close();// cierra la conexion
      }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex); 
    }
      return Query1;  
    }
    
    //elimina detalle del carrito
    public void elimina(){
        try{
          conexion=connectaBD(); // cra conexion a la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query para elminar carrito donde el Id y el Id del producto coincidan en la base de datos
          String Query="DELETE FROM Operaciones.Detalle_Carrito WHERE Id_Carrito="+idsCarritos.get(Carritos.getSelectedIndex())+" AND "
                  + "Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+" "
                  + "AND Cantidad="+Cantidad.getText()+" AND SubTotal ='"+subtotal.getText()+"'";
          corrida.executeUpdate(Query); //ejecutar query
          corrida.close();
          conexion.close(); // cierra la conexión
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
     }
    // modificar el detalle del carrito
     public void modifica(){
          try{
          conexion=connectaBD(); //crea la conexion
          java.sql.Statement corrida=conexion.createStatement();
          String i=Detalles.getValueAt(Detalles.getSelectedRow(), 0).toString();
          Pattern patron = Pattern.compile("\\d+");
          Matcher matcher = patron.matcher(i);
          String num="";
          while (matcher.find()) {
            num = matcher.group();
            }
          String Ca=Detalles.getValueAt(Detalles.getSelectedRow(),1).toString();
          String valor = Detalles.getValueAt(Detalles.getSelectedRow(), 3).toString();   
          String idProducto = buscaProducto(valor);
          //query para modificar el carrito, obitene los datos al hacer clic en el renglom dentro del jtable
          String Query="UPDATE Operaciones.Detalle_Carrito SET "
                  + "Id_Carrito="+idsCarritos.get(Carritos.getSelectedIndex())+",Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+",Cantidad="+Cantidad.getText()+",SubTotal=NULL "
                  + " WHERE Id_Carrito="+num+" AND Cantidad="+Ca+" AND Id_Producto="+idProducto+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion con la base de datos
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,"Sobrepasa los productos en existencia");
        }
     }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        subtotal = new javax.swing.JLabel();
        INSERTA = new javax.swing.JButton();
        MODIFICA = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Detalles = new javax.swing.JTable();
        ELIMINA = new javax.swing.JButton();
        Carritos = new javax.swing.JComboBox();
        Productos = new javax.swing.JComboBox();
        Cantidad = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Detalle Carrito");

        jLabel1.setFont(new java.awt.Font("sansserif", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 0, 204));
        jLabel1.setText("Detalle Carrito");

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("Carrito");

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Producto");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setText("Cantidad");

        jLabel5.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel5.setText("SubTotal");

        subtotal.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        subtotal.setForeground(new java.awt.Color(255, 51, 51));
        subtotal.setText("$0.00");

        INSERTA.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        INSERTA.setText("INSERTA");
        INSERTA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                INSERTAActionPerformed(evt);
            }
        });

        MODIFICA.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        MODIFICA.setText("MODIFICA");
        MODIFICA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                MODIFICAActionPerformed(evt);
            }
        });

        Detalles.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Detalles);

        ELIMINA.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        ELIMINA.setText("ELIMINA");
        ELIMINA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ELIMINAActionPerformed(evt);
            }
        });

        Cantidad.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel5)
                            .addGap(18, 18, Short.MAX_VALUE)
                            .addComponent(subtotal)
                            .addGap(251, 251, 251))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(layout.createSequentialGroup()
                                    .addComponent(jLabel4)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(120, 120, 120))
                                .addGroup(layout.createSequentialGroup()
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addGap(37, 37, 37)
                                            .addComponent(Carritos, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(18, 18, 18)
                                            .addComponent(Productos, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(MODIFICA)
                                .addComponent(INSERTA, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ELIMINA, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1122, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Carritos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(INSERTA))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Productos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(subtotal)))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(MODIFICA)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ELIMINA)))
                .addGap(36, 36, 36)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void INSERTAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_INSERTAActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_INSERTAActionPerformed

    private void MODIFICAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_MODIFICAActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_MODIFICAActionPerformed

    private void ELIMINAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ELIMINAActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_ELIMINAActionPerformed

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cantidad;
    private javax.swing.JComboBox Carritos;
    private javax.swing.JTable Detalles;
    private javax.swing.JButton ELIMINA;
    private javax.swing.JButton INSERTA;
    private javax.swing.JButton MODIFICA;
    private javax.swing.JComboBox Productos;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel subtotal;
    // End of variables declaration//GEN-END:variables
}
