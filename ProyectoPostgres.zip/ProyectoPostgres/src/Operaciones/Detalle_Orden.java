/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Operaciones;

import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
vista donde se muestra los detalles de las ordenes creadas
*/
public class Detalle_Orden extends javax.swing.JFrame {
    private String HOST="localhost";//host
    private String PUERTO="5432";//puerto
    private String DB="ComprasEnLinea";//base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB;  //dirección url 
    private Connection conexion=null;// variable para la base de datos
    public String idFuerte;
    public LinkedList<String> idsProductos=new LinkedList<>();
    public LinkedList<String> idsOrdenes=new LinkedList<>();
    public LinkedList<String> NomProductos=new LinkedList<>();
    public String user;// usuario
    /**
     * Creates new form Detalle_Orden
     */
    public Detalle_Orden(String U) {
        initComponents();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        muestra();
        productos();
        ordenes();
        cierra();
        usuario(U);
        user=U;
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            inserta.setEnabled(false);
            modifica.setEnabled(false);
            elimina.setEnabled(false);
        }
    }
    //cierra la vista
    public void cierra(){
         this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
              Orden d=new Orden(user);
              d.setVisible(true);
            }
        });
    }
        //obtiene los productos de la base de datos
    public void productos(){
        try{
            conexion=connectaBD();// crea la coenxion a la base de datos
            java.sql.Statement corrida=conexion.createStatement();
             //query para obtener los productos de la base de datos
            String Query="SELECT Nombre_Producto,Id_Producto,Precio_Publico_Proveedor FROM Articulo.Producto ORDER BY Id_Producto ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);// ejecutar el query
            while(columnas.next()){
               Productos.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               idsProductos.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    // método que obtiene un producto de la tabla Articulo.Producto
    public String buscaProducto(String cadena){
        String Query1="";// variable para el query
        try{
           conexion=connectaBD();// conexion de la base de datos
           java.sql.Statement corrida;
           // query que obtiene los datos del producto segun su nombre
           Query1="SELECT Id_Producto FROM Articulo.Producto WHERE Nombre_Producto='"+cadena+"'";
           corrida=conexion.createStatement();
           ResultSet columnas=corrida.executeQuery(Query1);  
             while(columnas.next()){
                Query1=columnas.getString(1);
               }
          corrida.close();
          conexion.close();// cierra la conexion
      }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex); 
    }
      return Query1;  
    }
    // obtiene las ordenes en la base de datos
    public void ordenes(){
    try{
            conexion=connectaBD();// conexion de la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query que obtiene las ordenes y los datos del proveedor
            String Query="SELECT O.Num_Orden,O.Id_Proveedor,P.Nombre_Provedoor FROM Operaciones.Orden O,Usuario.Proveedor P  "
                    + "WHERE O.Id_Proveedor=P.Id_Proveedor ORDER BY O.Num_Orden ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            while(columnas.next()){
               Ordenes.addItem(columnas.getString(1) + " " + columnas.getString(3));
               idsOrdenes.addLast(columnas.getString(1));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    //conecta con la base de datos
     public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
     // inserta un nuevo detalle orden
     public void inserta(){
         try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para insertar en la tabla Operaciones.Detalle_Orden una nueva orden
          String Query="INSERT INTO Operaciones.Detalle_Orden(Num_Orden,Id_Producto,Cantidad,SubTotal)"
                  + "VALUES("+idsOrdenes.get(Ordenes.getSelectedIndex())+","+idsProductos.get(Productos.getSelectedIndex())+","+Cantidad.getText()+",NULL)";
          corrida.executeUpdate(Query);// ejecutar el query
          corrida.close();
          conexion.close();// cierra la conexión
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,ex);
        }
     }
    
    //elimina una orden
     public void elimina(){
        try{
          conexion=connectaBD();// crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query que elimina una tupla de la tabla Operaciones.Detalle_Orden
          String Query="DELETE FROM Operaciones.Detalle_Orden WHERE Num_Orden="+idsOrdenes.get(Ordenes.getSelectedIndex())+" AND "
                  + "Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+""
                  + " AND Cantidad="+Cantidad.getText()+" AND SubTotal ='"+DetallesOrden.getValueAt(DetallesOrden.getSelectedRow(),2).toString()+"'";
          corrida.executeUpdate(Query);// ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexión
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
     }
     // modificar orden
     public void modifica(){
          try{
          conexion=connectaBD();// crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //obitene los nuevos datos de los textfield
          String i=DetallesOrden.getValueAt(DetallesOrden.getSelectedRow(), 0).toString();
          String Ca=DetallesOrden.getValueAt(DetallesOrden.getSelectedRow(),1).toString();
          String idProducto = buscaProducto(NomProductos.get(DetallesOrden.getSelectedRow()));
          //query que actualiza la informacion en la tabla Operaciones.Detalle_Orden
          String Query="UPDATE Operaciones.Detalle_Orden SET "
                  + "Num_Orden="+idsOrdenes.get(Ordenes.getSelectedIndex())+",Id_Producto="+idsProductos.get(Productos.getSelectedIndex())+",Cantidad="+Cantidad.getText()+",SubTotal=NULL "
                  + " WHERE Num_Orden="+i+" AND Cantidad="+Ca+" AND Id_Producto="+idProducto+"";
          corrida.executeUpdate(Query);// ejecuta el query
          corrida.close();
          conexion.close();// cierra la conexión
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,ex);
        }
     }
     // muestra los detalles de las ordenes
    public void muestra(){
     try{
            conexion=connectaBD(); // crea la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query para obtener las ordenes creadas segun el Id del proveedor y se ordenan de forma ascendente
            String Query="SELECT D.Num_Orden,D.Cantidad,D.SubTotal,P.Nombre_Producto,P.Precio_Publico_Proveedor FROM Articulo.Producto P,Operaciones.Detalle_Orden D "
                    + "WHERE D.Id_Producto=P.Id_Producto ORDER BY D.Num_Orden ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            // crea las columnas en el jtable
            model.addColumn("Número De Orden");
            model.addColumn("Cantidad");
            model.addColumn("SubTotal");
            model.addColumn("Nombre Producto -Precio Proveedor Producto");
            DetallesOrden.setModel(model);
            //llena las columnas con los datos
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4)+" - "+columnas.getString(5);

                NomProductos.add(columnas.getString(4));
                model.addRow(datos);
            }
            // obtiene los datos del renglón al hacer clic dentro del jtable
            DetallesOrden.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                Cantidad.setText(DetallesOrden.getValueAt(DetallesOrden.getSelectedRow(),1).toString());
                
                String id =buscaProducto(NomProductos.get(DetallesOrden.getSelectedRow()));
                
                for (int i =0; i < idsProductos.size(); i++){
                if(idsProductos.get(i).equals(id)){
                Productos.setSelectedIndex(i);
                    }
                    }
                
                String valor2 = DetallesOrden.getValueAt(DetallesOrden.getSelectedRow(), 0).toString();
                for (int i =0; i < idsOrdenes.size(); i++){
                if(idsOrdenes.get(i).equals(valor2)){
                Ordenes.setSelectedIndex(i);
                    }
                    }
                
                
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        DetallesOrden = new javax.swing.JTable();
        inserta = new javax.swing.JButton();
        elimina = new javax.swing.JButton();
        modifica = new javax.swing.JButton();
        Productos = new javax.swing.JComboBox();
        Ordenes = new javax.swing.JComboBox();
        Cantidad = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Detalle Orden");

        jLabel1.setFont(new java.awt.Font("sansserif", 3, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(255, 0, 51));
        jLabel1.setText("Detalle Orden");

        jLabel2.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel2.setText("Producto");

        jLabel3.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel3.setText("Orden");

        jLabel4.setFont(new java.awt.Font("sansserif", 0, 18)); // NOI18N
        jLabel4.setText("Cantidad");

        DetallesOrden.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(DetallesOrden);

        inserta.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        inserta.setText("INSERTA");
        inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertaActionPerformed(evt);
            }
        });

        elimina.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        elimina.setText("ELIMINA");
        elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminaActionPerformed(evt);
            }
        });

        modifica.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        modifica.setText("MODIFICA");
        modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificaActionPerformed(evt);
            }
        });

        Ordenes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OrdenesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 68, Short.MAX_VALUE)
                                .addComponent(elimina, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(Productos, 0, 203, Short.MAX_VALUE)
                                    .addComponent(Ordenes, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(inserta, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(modifica)))))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1154, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Productos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(inserta))
                .addGap(10, 10, 10)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(Ordenes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(modifica))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(Cantidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(elimina))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void OrdenesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OrdenesActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OrdenesActionPerformed

    private void modificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificaActionPerformed
        // TODO add your handling code here:
        modifica();
        NomProductos.clear();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_modificaActionPerformed

    private void eliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminaActionPerformed
        // TODO add your handling code here:
        elimina();
        NomProductos.clear();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_eliminaActionPerformed

    private void insertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertaActionPerformed
        // TODO add your handling code here:
        inserta();
        NomProductos.clear();
        muestra();
        Cantidad.setText("");
    }//GEN-LAST:event_insertaActionPerformed

 

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Cantidad;
    private javax.swing.JTable DetallesOrden;
    private javax.swing.JComboBox Ordenes;
    private javax.swing.JComboBox Productos;
    private javax.swing.JButton elimina;
    private javax.swing.JButton inserta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modifica;
    // End of variables declaration//GEN-END:variables
}
