/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Datos.Tarjeta_Cliente;
import Datos.Telefono_Cliente;
import Usuario.Cliente;
import Usuario.Proveedor;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
vista donde puedes ver, agregar, modificar o eliminar los teléfonos del cliente
*/


public class Telefono_Cliente extends javax.swing.JFrame {
    /*
    conjunto de variables necesarias para realizar la conexión a la 
    base de datos
    */
    private String HOST="localhost";//host
    private String PUERTO="5432";// puerto
    private String DB="ComprasEnLinea";// base de datos
    private String USER="postgres";// usuario
    private String PASS="postgres";// contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //direccion creada al juntar el host, puerto y base de datos
    private Connection conexion=null;// variable para la conexión
    public String id;//Variable para id de Cliente
    public String numeros;//Variable para guardar los numeros de teléfono
    public LinkedList<String> ids=new LinkedList<>();
    
    /**
     * Creates new form Telefono_Cliente
     */
    public Telefono_Cliente(String U) {
        initComponents();
        clientes();
        muestra();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(U);
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            Inserta.setEnabled(false);
            Modifica.setEnabled(false);
            Elimina.setEnabled(false);
        }
    }
    // metodo que obtiene los clientes de la base de datos ordenados de forma ascendente según el Id
 public void clientes(){
        try{
            conexion=connectaBD();
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener los datos del cliente, ordenados de forma ascendente según su Id
            String Query="SELECT Nombre_Cliente,Id_Cliente,Correo_Electronico FROM Usuario.Cliente ORDER BY Id_Cliente ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);
            while(columnas.next()){
               //inserta el cliente
               Cliente.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               ids.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
 
      // conecta a la base de datos a travez del driver, url, usuario y password
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    
     // inserta un teléfono en la base de datos segun el Id del cliente seleccionado
    public void inserta(){
        try{
          conexion=connectaBD(); // crea la conexión a la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          int id=Cliente.getSelectedIndex(); // selecciona el id del cliente
         // query que realiza la inserción de un nuevo télefono en la tabla Datos.Teléfono_Cliente
          String Query="INSERT INTO Datos.Telefono_Cliente(Id_Cliente,Numero)"
                  + "VALUES('"+ids.get(Cliente.getSelectedIndex())+"','"+Numero.getText()+"')";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();  //cierra la conexion
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, "Número Duplicado");
        }
    }
    
     //muestra en el jtable los teléfonos que estén relacionadas según el Id del cliente seleccionado
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la conexión con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query que muestra en el jtable los teléfonos del cliente, relacionando las tablas Datos.Telefono_cliente y Usuario.Cliente, ordenadas de forma ascendente
            String Query="SELECT D.Id_Cliente,D.Numero,P.Nombre_Cliente,P.Correo_Electronico FROM Datos.Telefono_Cliente D,Usuario.Cliente P WHERE D.Id_Cliente=P.Id_Cliente ORDER BY D.Id_Cliente ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);
            DefaultTableModel model=new DefaultTableModel();
            //se agregan las columnas al jtable
            model.addColumn("Id Cliente");
            model.addColumn("Número");
            model.addColumn("Nombre Cliente  - Correo Electrónico");
            JTelefonoC.setModel(model);
            //se llenan las columnas del jtable
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3)+" - "+columnas.getString(4);
                model.addRow(datos);
            }
            //obtiene los datos del teléfono al hacer clic en el renglón del jtable
            JTelefonoC.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    Numero.setText(JTelefonoC.getValueAt(JTelefonoC.getSelectedRow(),1).toString());
                    
                    for (int i =0; i < ids.size(); i++){
                    if(ids.get(i).equals(JTelefonoC.getValueAt(JTelefonoC.getSelectedRow(),0).toString())){
                        Cliente.setSelectedIndex(i);
                    }
                    }
                    // obtiene el id del renglón seleccionado
                    id=JTelefonoC.getValueAt(JTelefonoC.getSelectedRow(), 0).toString();
                    // obtiene el numero del renglón seleccionado
                    numeros=JTelefonoC.getValueAt(JTelefonoC.getSelectedRow(), 1).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
     //método para elimiar una tupla de la tabla Datos.Telefono_Cliente
    public void elimina(){
        try{
          conexion=connectaBD(); //crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para eliminar la tupla que corresponda al numero de teléfono de la tabla Datos.Telefono_Cliente
          String Query="DELETE FROM Datos.Telefono_Cliente WHERE Numero='"+Numero.getText()+"'";
          corrida.executeUpdate(Query);// ejecuta el query
          corrida.close();
          conexion.close();  //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    
//método para modificar una tupla de la tabla Datos.Telefono_cliente
    public void modifica(){
        try{
          conexion=connectaBD(); //crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para actualizar los datos de la tupla relacionada con el Id del cliente y el numero de telefono
          String Query="UPDATE Datos.Telefono_Cliente SET Numero='"+Numero.getText()+"',Id_Cliente='"+ids.get(Cliente.getSelectedIndex())+"'"
                  + "WHERE Id_Cliente="+id+" AND Numero='"+numeros+"'";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, "Número Duplicado");  
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Inserta = new javax.swing.JButton();
        Modifica = new javax.swing.JButton();
        Elimina = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTelefonoC = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        Numero = new javax.swing.JTextField();
        Cliente = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Teléfono Cliente");

        Inserta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Inserta.setText("INSERTA");
        Inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertaActionPerformed(evt);
            }
        });

        Modifica.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Modifica.setText("MODIFICA");
        Modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificaActionPerformed(evt);
            }
        });

        Elimina.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Elimina.setText("ELIMINA");
        Elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminaActionPerformed(evt);
            }
        });

        JTelefonoC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(JTelefonoC);

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 12)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("Teléfono Cliente");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Número");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Cliente");

        Numero.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Cliente.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Cliente, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Modifica, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(Inserta, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(75, 75, 75)
                        .addComponent(Elimina)
                        .addGap(119, 119, 119)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(33, 33, 33)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(Cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(56, 56, 56)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 283, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(36, 36, 36)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(Inserta, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                            .addComponent(Elimina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addComponent(Modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void InsertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertaActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Numero.setText("");                        
    }//GEN-LAST:event_InsertaActionPerformed

    private void EliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminaActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Numero.setText("");
    }//GEN-LAST:event_EliminaActionPerformed

    private void ModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificaActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
        Numero.setText("");
        
    }//GEN-LAST:event_ModificaActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox Cliente;
    private javax.swing.JButton Elimina;
    private javax.swing.JButton Inserta;
    private javax.swing.JTable JTelefonoC;
    private javax.swing.JButton Modifica;
    private javax.swing.JTextField Numero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
