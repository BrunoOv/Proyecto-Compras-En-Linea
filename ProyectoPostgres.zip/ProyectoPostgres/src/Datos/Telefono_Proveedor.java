/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Datos.Tarjeta_Cliente;
import Datos.Telefono_Cliente;
import Usuario.Proveedor;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.LinkedList;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
    vista donde puedes ver, agregar, modificar o eliminar los teléfonos del proveedor
*/
public class Telefono_Proveedor extends javax.swing.JFrame {
    /*
    conjunto de variables necesarias para realizar la conexión a la 
    base de datos
    */
    private String HOST="localhost"; //host
    private String PUERTO="5432"; // puerto
    private String DB="ComprasEnLinea"; // base de datos
    private String USER="postgres"; // usuario
    private String PASS="postgres"; // contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //direccion creada al juntar el host, puerto y base de datos
    private Connection conexion=null; // variable para la conexión
    public String id; //Variable para id del Proveedor
    public String numeros; //Variable para guardar los numeros de teléfono
    public LinkedList<String> ids=new LinkedList<>();
    
    /**
     * Creates new form Telefono_Proveedor
     */
    public Telefono_Proveedor(String U) {
        initComponents();
        muestra();
        proveedores();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(U);
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            Inserta.setEnabled(false);
            Modifica.setEnabled(false);
            Elimina.setEnabled(false);
        }
    }
    
    // metodo que obtiene los Proveedores de la base de datos ordenados de forma ascendente según el Id
    public void proveedores(){
        try{
            conexion=connectaBD(); // crea la conexión a la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener los datos del proveedor, ordenados de forma ascendente según su Id
            String Query="SELECT Nombre_Provedoor,Id_Proveedor,Correo_Electronico FROM Usuario.Proveedor ORDER BY Id_Proveedor ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); // ejecutar el query
            while(columnas.next()){
               Proveedor.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               ids.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    // conecta a la base de datos a travez del driver, url, usuario y password
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    
    // inserta un teléfono en la base de datos segun el Id del proveedor seleccionado
    public void inserta(){
        try{
          conexion=connectaBD(); // crea la conexion a la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          int id=Proveedor.getSelectedIndex();// selecciona el id del proveedor
          // query que realiza la inserción de un nuevo télefono en la tabla Datos.Teléfono_Proveedor
          String Query="INSERT INTO Datos.Telefono_Proveedor(Id_Proveedor,Numero)"
                  + "VALUES('"+ids.get(Proveedor.getSelectedIndex())+"','"+Numero.getText()+"')";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();// cierra la conexion con la base de datos
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, "Número Duplicado");
        }
    }     

    //muestra en el jtable los teléfonos que estén relacionadas según el Id del proveedor seleccionado
    public void muestra(){
        try{
            conexion=connectaBD(); //crea la conexion con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query que muestra en el jtable los teléfonos del proveedor, relacionando las tablas Datos.Telefono_Proveedor y Usuario.Proveedor, ordenadas de forma ascendente
            String Query="SELECT D.Id_Proveedor,D.Numero,P.Nombre_Provedoor,P.Correo_Electronico FROM Datos.Telefono_Proveedor D,Usuario.Proveedor P WHERE D.Id_Proveedor=P.Id_Proveedor ORDER BY D.Id_Proveedor ASC";
            String[]datos =new String[5];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);
            DefaultTableModel model=new DefaultTableModel();
            //se agregan las columnas al jtable
            model.addColumn("Id Proveedor");
            model.addColumn("Número");
            model.addColumn("Nombre Proveedor - Correo Electrónico");
            JTelefonoP.setModel(model);
            //se llenan las columnas del jtable
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3)+" - "+columnas.getString(4);
                model.addRow(datos);
            }
            //obtiene los datos del teléfono al hacer clic en el renglón del jtable
            JTelefonoP.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    Numero.setText(JTelefonoP.getValueAt(JTelefonoP.getSelectedRow(),1).toString());
                    
                    for (int i =0; i < ids.size(); i++){
                    if(ids.get(i).equals(JTelefonoP.getValueAt(JTelefonoP.getSelectedRow(),0).toString())){
                        Proveedor.setSelectedIndex(i);
                    }
                    }
                    // obtiene el id del renglón seleccionado
                    id=JTelefonoP.getValueAt(JTelefonoP.getSelectedRow(), 0).toString();
                    // obtiene el numero del renglón seleccionado
                    numeros=JTelefonoP.getValueAt(JTelefonoP.getSelectedRow(), 1).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    //método para elimiar una tupla de la tabla Datos.Telefono_Proveedor
    public void elimina(){
        try{
          conexion=connectaBD();//crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para eliminar la tupla que corresponda al numero de teléfono de la tabla Datos.Telefono_Proveedor
          String Query="DELETE FROM Datos.Telefono_Proveedor WHERE Numero='"+Numero.getText()+"'";
          corrida.executeUpdate(Query); // ejecutar query
          corrida.close();
          conexion.close(); // cierra la conexión con la base de dayos
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    //método para modificar una tupla de la tabla Datos.Telefono_Proveedor
    public void modifica(){
        try{
          conexion=connectaBD(); //crea la conexion con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para actualizar los datos de la tupla relacionada con el Id del proveedor y el numero de telefono
          String Query="UPDATE Datos.Telefono_Proveedor SET Numero='"+Numero.getText()+"',Id_Proveedor='"+ids.get(Proveedor.getSelectedIndex())+"'"
                  + "WHERE Id_Proveedor="+id+" AND Numero='"+numeros+"'";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); // cierra la conexion con la base de datos
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, "Numero Duplicado");  
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        Numero = new javax.swing.JTextField();
        Proveedor = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTelefonoP = new javax.swing.JTable();
        Inserta = new javax.swing.JButton();
        Modifica = new javax.swing.JButton();
        Elimina = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        jLabel3.setText("jLabel3");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Teléfono Proveedor");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel1.setText("Número");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Proveedor");

        Proveedor.setToolTipText("");

        JTelefonoP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(JTelefonoP);

        Inserta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Inserta.setText("INSERTA");
        Inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertaActionPerformed(evt);
            }
        });

        Modifica.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Modifica.setText("MODIFICA");
        Modifica.setToolTipText("");
        Modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificaActionPerformed(evt);
            }
        });

        Elimina.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Elimina.setText("ELIMINA");
        Elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminaActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 204));
        jLabel4.setText("Teléfono Proveedor");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 912, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(Numero)
                        .addGap(112, 112, 112)
                        .addComponent(Inserta, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(Elimina, javax.swing.GroupLayout.PREFERRED_SIZE, 95, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(167, 167, 167))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(Proveedor, javax.swing.GroupLayout.PREFERRED_SIZE, 347, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel4)
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Inserta)
                    .addComponent(Elimina)
                    .addComponent(Modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Proveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void InsertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertaActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Numero.setText("");
    }//GEN-LAST:event_InsertaActionPerformed

    private void EliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminaActionPerformed
        // TODO add your handling code here:
        elimina();
        muestra();
        Numero.setText("");
    }//GEN-LAST:event_EliminaActionPerformed

    private void ModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificaActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
    }//GEN-LAST:event_ModificaActionPerformed


 
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Elimina;
    private javax.swing.JButton Inserta;
    private javax.swing.JTable JTelefonoP;
    private javax.swing.JButton Modifica;
    private javax.swing.JTextField Numero;
    private javax.swing.JComboBox Proveedor;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
