/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Usuario.Cliente;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedList;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ComboBoxModel;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/*
vista donde puedes ver, agregar, modificar o eliminar las tarjetas del cliente
*/

public class Tarjeta_Cliente extends javax.swing.JFrame {
    /*
    conjunto de variables necesarias para realizar la conexión a la 
    base de datos
    */
    private String HOST="localhost"; //host
    private String PUERTO="5432"; // puerto
    private String DB="ComprasEnLinea"; // base de datos
    private String USER="postgres"; // usuario
    private String PASS="postgres"; // contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; //direccion creada al juntar el host, puerto y base de datos
    private Connection conexion=null; // variable para la conexión
    public String id; //Variable para id de Cliente 
    public String numeros; //Variable para guardar los numeros de la tarjeta
    public LinkedList<String> ids=new LinkedList<>();
    public LinkedList<String> fechas=new LinkedList<>();
    
    /**
     * Creates new form Tarjeta_Cliente
     */
    public Tarjeta_Cliente(String U) {
        initComponents();
        clientes();
        muestra();
        fecha();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(U);
    }
    
    public void usuario(String u){
        if(u.equals("pablo")){
            inserta.setEnabled(false);
            modifica.setEnabled(false);
            elimina.setEnabled(false);
        }
    }
    // método para desplegar el calendario
    public void fecha(){
        Calendar fechaActual = Calendar.getInstance();
        fechaActual.add(Calendar.MONTH, 5);
        Date.setSelectableDateRange(fechaActual.getTime(), null);           
    }
    
    // metodo que obtiene los clientes de la base de datos ordenados de forma ascendente según el Id
     public void clientes(){
        try{
            conexion=connectaBD(); // realiza la conexión a la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener los datos del cliente, ordenados de forma ascendente según su Id
            String Query="SELECT Nombre_Cliente,Id_Cliente,Correo_Electronico FROM Usuario.Cliente ORDER BY Id_Cliente ASC";
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);
            while(columnas.next()){
                // inserta el cliente
               Cliente.addItem(columnas.getString(1)+" - "+columnas.getString(3));
               ids.addLast(columnas.getString(2));
            }
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
     // conecta a la base de datos a travez del driver, url, usuario y password
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // inserta una tarjeta en la base de datos segun el Id del cliente seleccionado
    public void inserta(){
        try{
          conexion=connectaBD(); //crea la conexión a la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          int id=Cliente.getSelectedIndex(); // selecciona el id del cliente
          // query que realiza la inserción de una nueva tarjeta en la tabla Datos.tarjeta_cliente
          String Query="INSERT INTO Datos.Tarjeta_Cliente(Id_Cliente,Numero_Tarjeta,CVV,Banco,Fecha)"
                  + "VALUES('"+ids.get(Cliente.getSelectedIndex())+"','"+Numero.getText()+"','"+cvv.getText()+"','"+Banco.getText()+"','"+(((JTextField)Date.getDateEditor().getUiComponent()).getText())+"')";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();  //cierra la conexion
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null,"Numero De Tarjeta Duplicado");
        }
    }
    //muestra en el jtable las tarjetas que estén relacionadas según el Id del cliente seleccionado
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la conexión con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            //query que muestra en el jtable las tarjetas del cliente, relacionando las tablas Datos.Tarjeta_cliente y Usuario.Cliente, ordenadas de forma ascendente
            String Query="SELECT T.Id_Cliente,T.Numero_Tarjeta,T.CVV,T.Banco,to_char(Fecha,'MM/yyyy'),C.Nombre_Cliente,C.Correo_Electronico,Fecha FROM Datos.Tarjeta_Cliente T,Usuario.Cliente C WHERE T.Id_Cliente=C.Id_Cliente ORDER BY T.Id_Cliente ASC";
            String[]datos =new String[8];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query);
            DefaultTableModel model=new DefaultTableModel();
            //se agregan las columnas al jtable
            model.addColumn("Id Cliente"); 
            model.addColumn("Número Tarjeta");
            model.addColumn("CVV");
            model.addColumn("Banco");
            model.addColumn("Fecha");
            model.addColumn("Nombre Cliente - Correo Electrónico");
            Ttarjeta.setModel(model);
            //se llenan las columnas del jtable
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);
                datos[3]=columnas.getString(4);
                datos[4]=columnas.getString(5);
                datos[5]=columnas.getString(6)+" - "+columnas.getString(7);
                model.addRow(datos);
            }
            //obtiene los datos de la tarjeta al hacer clic en el renglón del jtable
            Ttarjeta.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                if(Mouse_evt.getClickCount()==1){
                    //se llenan los jtextfield con los datos de la tarjeta seleccionada
                    Numero.setText(Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(),1).toString());
                    cvv.setText(Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(),2).toString());
                    Banco.setText(Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(),3).toString());
                    for (int i =0; i < ids.size(); i++){
                    if(ids.get(i).equals(Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(),0).toString())){
                        Cliente.setSelectedIndex(i);
                    }
                    }
                    try{
                    conexion=connectaBD(); //crea la conexión con la base de datos
                    java.sql.Statement corrida;
                    //query para obtener la fecha de la tarjeta convertida en char/cadena de la tabla Datos.Tarejta_Cliente
                    String Query="SELECT to_char(Fecha,'yyyy/MM/dd') FROM Datos.Tarjeta_Cliente WHERE Numero_Tarjeta='"+Numero.getText()+"'";
                
                    corrida=conexion.createStatement();
                    ResultSet columnas=corrida.executeQuery(Query);  // ejecuta el query
                    while(columnas.next()){
                    ((JTextField)Date.getDateEditor().getUiComponent()).setText(columnas.getString(1));
                    }
                    corrida.close();
                    conexion.close();  //cierra la conexion
                    }catch(Exception ex){
                        JOptionPane.showMessageDialog(null, ex); 
                    }
                    // obtiene el id del cliente al momento de seleccionar el renglo del jtable
                    id=Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(), 0).toString();
                    // obtiene los numeros de la tarjeta al seleccionar el renglón dentro del jtable
                    numeros=Ttarjeta.getValueAt(Ttarjeta.getSelectedRow(), 1).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    //método para elimiar una tupla de la tabla Datos.Tarjeta_cliente
    public void elimina(){
        try{
          conexion=connectaBD(); //crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para eliminar la tupla que corresponda al numero de tarjeta de la tabla Datos.Tarjeta_cliente
          String Query="DELETE FROM Datos.Tarjeta_Cliente WHERE Numero_Tarjeta='"+Numero.getText()+"'";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();   //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    
    //método para modificar una tupla de la tabla Datos.Tarjeta_Cliente
    public void modifica(){
        try{
          conexion=connectaBD(); //crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para actualizar los datos de la tupla relacionada con el Id del cliente y el numero de la tarjeta
          String Query="UPDATE Datos.Tarjeta_Cliente SET Numero_Tarjeta='"+Numero.getText()+"',Id_Cliente='"+ids.get(Cliente.getSelectedIndex())+"',"
                  + "CVV='"+cvv.getText()+"',Banco='"+Banco.getText()+"',Fecha='"+(((JTextField)Date.getDateEditor().getUiComponent()).getText())+"'"
                  + "WHERE Id_Cliente="+id+" AND Numero_Tarjeta='"+numeros+"'";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close();  //cierra la conexion
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, "Numero De Tarjeta Duplicado");  
        }
    }
    
    
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Numero = new javax.swing.JTextField();
        cvv = new javax.swing.JTextField();
        Banco = new javax.swing.JTextField();
        Cliente = new javax.swing.JComboBox();
        Date = new com.toedter.calendar.JDateChooser();
        jScrollPane1 = new javax.swing.JScrollPane();
        Ttarjeta = new javax.swing.JTable();
        inserta = new javax.swing.JButton();
        elimina = new javax.swing.JButton();
        modifica = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("TarjetaCliente");

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel1.setText("Tarjeta Cliente");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Número De Tarjeta");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("CVV");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Banco");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Fecha");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Cliente");

        Numero.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        Numero.setToolTipText("");

        cvv.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N

        Banco.setFont(new java.awt.Font("sansserif", 0, 14)); // NOI18N
        Banco.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BancoActionPerformed(evt);
            }
        });

        Cliente.setModel(new javax.swing.DefaultComboBoxModel(new String[] { }));
        Cliente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ClienteActionPerformed(evt);
            }
        });

        Date.setDateFormatString("yyyy/MM/d");

        Ttarjeta.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Ttarjeta);

        inserta.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        inserta.setText("INSERTA");
        inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertaActionPerformed(evt);
            }
        });

        elimina.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        elimina.setText("ELIMINA");
        elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminaActionPerformed(evt);
            }
        });

        modifica.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        modifica.setText("MODIFICA");
        modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel2)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, 204, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel5)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(Date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGap(153, 153, 153))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel6)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(Cliente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGroup(layout.createSequentialGroup()
                                            .addComponent(jLabel3)
                                            .addGap(14, 14, 14)
                                            .addComponent(cvv, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addComponent(jLabel4)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(Banco, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(186, 186, 186)))
                                .addGap(45, 45, 45)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(inserta, javax.swing.GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE)
                                    .addComponent(elimina, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(55, 55, 55)
                                .addComponent(modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 602, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(Numero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(inserta, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(cvv, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel4)
                            .addComponent(Banco, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5)
                            .addComponent(Date, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(Cliente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addComponent(elimina, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 285, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BancoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BancoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_BancoActionPerformed

    private void ClienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ClienteActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ClienteActionPerformed

    private void insertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertaActionPerformed
        // TODO add your handling code here:
        inserta();
        muestra();
        Numero.setText("");
        cvv.setText("");
        Banco.setText("");
    }//GEN-LAST:event_insertaActionPerformed

    private void modificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificaActionPerformed
        // TODO add your handling code here:
        modifica();
        muestra();
         Numero.setText("");
        cvv.setText("");
        Banco.setText("");
    }//GEN-LAST:event_modificaActionPerformed

    private void eliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminaActionPerformed
        // TODO add your handling code here:
       elimina();
       muestra();
        Numero.setText("");
        cvv.setText("");
        Banco.setText("");
    }//GEN-LAST:event_eliminaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Banco;
    private javax.swing.JComboBox Cliente;
    private com.toedter.calendar.JDateChooser Date;
    private javax.swing.JTextField Numero;
    private javax.swing.JTable Ttarjeta;
    private javax.swing.JTextField cvv;
    private javax.swing.JButton elimina;
    private javax.swing.JButton inserta;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton modifica;
    // End of variables declaration//GEN-END:variables
}
