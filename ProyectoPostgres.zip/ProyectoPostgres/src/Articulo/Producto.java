/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Articulo;
import Datos.Tarjeta_Cliente;
import Datos.Telefono_Cliente;
import Menu.Menu;
import java.sql.Connection;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/*
vista en la cual puedes ver, modificar, agregar o eliminar productos de la base de datos
*/

public class Producto extends javax.swing.JFrame {
    private String HOST="localhost"; //host
    private String PUERTO="5432"; //puerto
    private String DB="ComprasEnLinea"; //base de datos
    private String USER="postgres";//usuario
    private String PASS="postgres";//contraseña
    public  String url="jdbc:postgresql://"+HOST+":"+PUERTO+"/"+DB; // direccion url
    private Connection conexion=null; // conexion con la base de datos
    public String id;// id para cada producto
    /**
     * Creates new form Producto
     */
    public Producto(String u) {
        initComponents();
        muestra();
        this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        usuario(u);
    }
    public void usuario(String u){
        if(u.equals("pablo")){
            Inserta.setEnabled(false);
            Modifica.setEnabled(false);
            Elimina.setEnabled(false);
        }
    }
    // método para conectar con la base de datos
    public Connection connectaBD(){
        Connection cone=null;
        try{
            Class.forName("org.postgresql.Driver");
            cone=DriverManager.getConnection(url,USER,PASS);
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex);
        }
        return cone;
    }
    // inserta un producto en la base de datos
    public void inserta(){
        //verifica si todos los campos del producto están completos
        if(Nombre.getText().equalsIgnoreCase("")||PrecioPublico.getText().equalsIgnoreCase("")
          ||PrecioProveedor.getText().equalsIgnoreCase("")||Color.getText().equalsIgnoreCase("")
          ||Stock.getText().equalsIgnoreCase("")){
        JOptionPane.showMessageDialog(this, "Casillas vacias");
        }else{
          try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // inserta un nuevo producto en la tabla Articulo.Producto
          String Query="INSERT INTO Articulo.Producto(Nombre_Producto,Precio_Publico_Producto,Precio_Publico_Proveedor,Color,Stock)"
                  + "VALUES('"+Nombre.getText()+"',CAST('"+PrecioPublico.getText()+"' AS DECIMAL(10,2)) ,CAST('"+PrecioProveedor.getText()+"' AS DECIMAL(10,2)),'"+Color.getText()+"',"+Stock.getText()+")";
          corrida.executeUpdate(Query); // ejecuta el query
          corrida.close();
          conexion.close();// cierra la conexión con la base ded atos
          //JOptionPane.showMessageDialog(null, "INSERTO");
        }catch(Exception ex){
        JOptionPane.showMessageDialog(null, ex);
        }
        }
    }
    
    //muestra todos los productos en la base de datos 
    public void muestra(){
        try{
            conexion=connectaBD(); // crea la conexión con la base de datos
            java.sql.Statement corrida=conexion.createStatement();
            // query para obtener los productos de la base de datos, ordenados de manera ascendente según su Id
            String Query="Select id_producto,nombre_producto,precio_publico_producto\n" +
            ",precio_publico_proveedor\n" +
            ",color,stock FROM Articulo.Producto\n" +
            "ORDER BY Id_Producto ASC";
            String[]datos =new String[6];
            corrida=conexion.createStatement();
            ResultSet columnas=corrida.executeQuery(Query); //ejecuta el query
            DefaultTableModel model=new DefaultTableModel();
            //crea las columnas en el jtable
            model.addColumn("Id Producto");
            model.addColumn("Nombre Producto");
            model.addColumn("Precio Público Producto");
            model.addColumn("Precio Proveedor Producto");
            model.addColumn("Color");
            model.addColumn("Stock");
            
            Productos.setModel(model);
            //llena las columnas del jtable
            while(columnas.next()){
                datos[0]=columnas.getString(1);
                datos[1]=columnas.getString(2);
                datos[2]=columnas.getString(3);//publico
                datos[3]=columnas.getString(4);//proveedor
                datos[4]=columnas.getString(5);
                datos[5]=columnas.getString(6); 
                model.addRow(datos);
            }
            // obtiene la informacion del producto al hacer clic en el renglón del jtable
            Productos.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent Mouse_evt){
                JTable table=(JTable) Mouse_evt.getSource();
                Point point = Mouse_evt.getPoint();
                int row=table.rowAtPoint(point);
                // llena los jtextfield con los datos del producto
                if(Mouse_evt.getClickCount()==1){
                    Nombre.setText(Productos.getValueAt(Productos.getSelectedRow(),1).toString());
                    PrecioPublico.setText(Productos.getValueAt(Productos.getSelectedRow(),2).toString());
                    PrecioProveedor.setText(Productos.getValueAt(Productos.getSelectedRow(),3).toString());
                    Color.setText(Productos.getValueAt(Productos.getSelectedRow(),4).toString());
                    Stock.setText(Productos.getValueAt(Productos.getSelectedRow(),5).toString());
                    id=Productos.getValueAt(Productos.getSelectedRow(), 0).toString();
                }
            }
            });
        }catch(Exception ex){
            JOptionPane.showMessageDialog(null, ex); 
        }
    }
    
    // método para eliminar un producto
    public void elimina(){
        try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          //query para eliminar un producto de la tabla Articulo.Producto
          String Query="DELETE FROM Articulo.Producto WHERE Id_Producto="+id+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexión con la base de datos
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);
        }
    }
    //actualiza los datos del producto
    public void modifica(){
        try{
          conexion=connectaBD(); // crea la conexión con la base de datos
          java.sql.Statement corrida=conexion.createStatement();
          // query para actualizar los datos del producto
          String Query="UPDATE Articulo.Producto SET Nombre_Producto='"+Nombre.getText()+"',Precio_Publico_Producto='"+PrecioPublico.getText()+"',Precio_Publico_Proveedor='"+PrecioProveedor.getText()+"',"
                  + "Color='"+Color.getText()+"',Stock="+Stock.getText()+" WHERE Id_Producto="+id+"";
          corrida.executeUpdate(Query); //ejecuta el query
          corrida.close();
          conexion.close(); //cierra la conexión con la base de datos 
        }catch(Exception ex){
          JOptionPane.showMessageDialog(null, ex);  
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        Nombre = new javax.swing.JTextField();
        PrecioPublico = new javax.swing.JTextField();
        PrecioProveedor = new javax.swing.JTextField();
        Color = new javax.swing.JTextField();
        Stock = new javax.swing.JTextField();
        Inserta = new javax.swing.JButton();
        Modifica = new javax.swing.JButton();
        Elimina = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Productos = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Producto");

        jLabel1.setFont(new java.awt.Font("Tahoma", 2, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 204, 204));
        jLabel1.setText("Producto");

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel3.setText("Precio Público");

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("Precio Proveedor");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("Color");

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("Stock");

        Nombre.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        Nombre.setToolTipText("");

        PrecioPublico.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        PrecioProveedor.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Color.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Stock.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        Inserta.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Inserta.setText("INSERTA");
        Inserta.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                InsertaActionPerformed(evt);
            }
        });

        Modifica.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Modifica.setText("MODIFICA");
        Modifica.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ModificaActionPerformed(evt);
            }
        });

        Elimina.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        Elimina.setText("ELIMINA");
        Elimina.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EliminaActionPerformed(evt);
            }
        });

        Productos.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(Productos);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 990, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING))
                        .addGap(27, 27, 27)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(Stock, javax.swing.GroupLayout.DEFAULT_SIZE, 95, Short.MAX_VALUE)
                                    .addComponent(Color, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(PrecioProveedor)
                                    .addComponent(PrecioPublico))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Inserta, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 117, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Elimina, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(75, 75, 75)
                                .addComponent(Modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(67, 67, 67))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(Nombre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(111, 111, 111)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6)
                            .addComponent(Stock, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(Modifica, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(Inserta, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(30, 30, 30)
                                .addComponent(Elimina, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel3)
                                    .addComponent(PrecioPublico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(PrecioProveedor, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5)
                                    .addComponent(Color, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void InsertaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_InsertaActionPerformed
        // TODO add your handling code here:
        inserta();
        Nombre.setText("");
        PrecioPublico.setText("");
        PrecioProveedor.setText("");
        Color.setText("");
        Stock.setText("");
        muestra();
    }//GEN-LAST:event_InsertaActionPerformed

    private void EliminaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EliminaActionPerformed
        // TODO add your handling code here:
        elimina();
        Nombre.setText("");
        PrecioPublico.setText("");
        PrecioProveedor.setText("");
        Color.setText("");
        Stock.setText("");
        muestra();
    }//GEN-LAST:event_EliminaActionPerformed

    private void ModificaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ModificaActionPerformed
        // TODO add your handling code here:
        modifica();
        Nombre.setText("");
        PrecioPublico.setText("");
        PrecioProveedor.setText("");
        Color.setText("");
        Stock.setText("");
        muestra();
    }//GEN-LAST:event_ModificaActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Color;
    private javax.swing.JButton Elimina;
    private javax.swing.JButton Inserta;
    private javax.swing.JButton Modifica;
    private javax.swing.JTextField Nombre;
    private javax.swing.JTextField PrecioProveedor;
    private javax.swing.JTextField PrecioPublico;
    private javax.swing.JTable Productos;
    private javax.swing.JTextField Stock;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
